# LMS Frontend Structure

> **Base URL:** `/`
> **API Base:** `/api/`
> **Auth:** Token-based (stored in localStorage / httpOnly cookie)
> **Design direction:** RTL-ready (Arabic/Quran/Culture content), clean dashboard layout

---

## Table of Contents

1. [Route Map](#route-map)
2. [Auth Pages](#1-auth-pages)
3. [Admin Dashboard](#2-admin-dashboard)
4. [Center Admin Dashboard](#3-center-admin-dashboard)
5. [Teacher Dashboard](#4-teacher-dashboard)
6. [Parent Dashboard](#5-parent-dashboard)
7. [Student Portal](#6-student-portal)
8. [Shared Components](#7-shared-components)
9. [Access Control Matrix](#8-access-control-matrix)
10. [Data Flow Summary](#9-data-flow-summary)

---

## Route Map

```
/                          → Redirect based on role after login
/login                     → User login (teacher | parent | center_admin | admin)
/student-login             → Student portal login (separate flow)
/register/:token           → Invitation-based registration

/admin/*                   → Admin-only (is_staff)
/center/*                  → Center Admin role
/teacher/*                 → Teacher role
/parent/*                  → Parent role
/student/*                 → Student portal (after student login)

/403                       → Forbidden
/404                       → Not Found
```

---

## 1. Auth Pages

### 1.1 `/login` — User Login

**API:** `POST /api/auth/login/`

**Layout:** Centered card, logo at top

**Fields:**
- Email (input)
- Password (input, toggle visibility)
- Submit button

**Behavior:**
- On success → read `role` from response → redirect:
  - `admin` / `is_staff=true` → `/admin/dashboard`
  - `center_admin` → `/center/dashboard`
  - `teacher` → `/teacher/dashboard`
  - `parent` → `/parent/dashboard`
- On error → inline error message (invalid credentials / account inactive)

**Extra link:**
- "Student? Login here" → `/student-login`

---

### 1.2 `/student-login` — Student Portal Login

**API:** `POST /api/student-login/`

**Layout:** Same centered card, different accent color to distinguish from staff login

**Fields:**
- Username (input)
- Password (input, toggle visibility)
- Submit button

**Behavior:**
- On success → redirect `/student/dashboard`
- On error → inline error

**Extra link:**
- "Staff login" → `/login`

---

### 1.3 `/register/:token` — Invitation Registration

**API:**
- `GET /api/register/?token=<uuid>` — validate token & prefill email/role
- `POST /api/register/` — submit registration

**Layout:** Centered card with step indicator (validate → fill form → submitted)

**Step 1 — Token Validation (auto on page load):**
- Show loading spinner
- If token invalid/expired → show error card with "Contact your administrator"
- If valid → proceed to form

**Step 2 — Fill Registration Form:**
- Full Name (input)
- Email (prefilled from invitation, read-only)
- Role (prefilled, displayed as badge, read-only)
- Password (input)
- Confirm Password (input)
- Submit button

**Step 3 — Submitted:**
- Success card: "Your registration is pending approval."
- No redirect; user waits for admin approval

---

## 2. Admin Dashboard

> Role: `is_staff = true` — full system access via Django admin + any center_admin feature

**Note:** The primary admin interface is Django's `/admin/`. The custom frontend can optionally expose a lightweight admin panel that mirrors Center Admin + user impersonation.

### 2.1 `/admin/dashboard`

**Sidebar links:**
- Dashboard
- Users → `/admin/users`
- Invitations → `/admin/invitations`
- Registration Requests → `/admin/registration-requests`
- Student Requests → `/admin/student-requests`
- Django Admin → `/admin/` (external link)

**Content:** Same as Center Admin dashboard but with no permission restrictions.

---

## 3. Center Admin Dashboard

> Role: `center_admin` — manages users, invitations, registration, student requests

### 3.1 `/center/dashboard` — Overview

**API:** `GET /api/me/`

**Layout:** Sidebar + main content area

**Sidebar links:**
- Dashboard
- Invitations
- Registration Requests
- Users
- Student Requests

**Dashboard cards (stat widgets):**
- Total active users
- Pending registration requests
- Pending student requests
- Total invitations sent

---

### 3.2 `/center/invitations` — Invitation List

**API:** `GET /api/invitations/` (requires `can_view_invitations`)

**Layout:** Page header + toolbar + data table

**Toolbar:**
- "New Invitation" button (→ opens drawer/modal)
- Filter by role (All | Teacher | Parent | Center Admin)
- Filter by status (All | Pending | Used | Expired)

**Table columns:**
| Column | Description |
|--------|-------------|
| Email | Recipient email |
| Role | Badge (Teacher / Parent / Center Admin) |
| Status | Badge (Pending / Used / Expired) |
| Expires At | Formatted date |
| Permissions | Count badge (e.g. "5 permissions") |
| Created By | Email of creator |
| Actions | Copy link, Delete |

**Copy Invitation Link:** constructs `/register/:token` URL and copies to clipboard.

---

### 3.3 Invitation Create Drawer/Modal

**API:** `POST /api/invitations/` (requires `can_create_invitation`)

**Fields:**
- Email (input, optional — if blank generates open link)
- Role (select: Teacher | Parent | Center Admin)
- Expires At (date-time picker, default +7 days)
- Permissions (multi-select checkbox list, shown only when role = `center_admin`)
  - Loaded from `GET /api/permissions/`
  - Grouped by category

**Submit:** Creates invitation, closes drawer, refreshes table.

---

### 3.4 `/center/registration-requests` — Registration Requests

**API:** `GET /api/registration-requests/` (requires `can_view_requests`)

**Layout:** Toolbar + data table + action modals

**Toolbar:**
- Filter by status (All | Pending | Approved | Rejected)

**Table columns:**
| Column | Description |
|--------|-------------|
| Name | Applicant name |
| Email | Applicant email |
| Role | Badge |
| Status | Badge (Pending / Approved / Rejected) |
| Submitted At | Date |
| Actions | Approve / Reject (only for Pending) |

**Approve action:**
- `POST /api/registration-requests/:id/approve/`
- Confirm dialog before submitting
- On success → row status updates to "Approved"

**Reject action:**
- `POST /api/registration-requests/:id/reject/`
- Confirm dialog before submitting
- On success → row status updates to "Rejected"

---

### 3.5 `/center/users` — User List

**API:** `GET /api/users/` (requires `can_view_users`)

**Toolbar:**
- Search by name or email
- Filter by role

**Table columns:**
| Column | Description |
|--------|-------------|
| Name | User full name |
| Email | User email |
| Role | Badge |
| Status | Active / Inactive badge |
| Actions | View / Edit / Delete |

---

### 3.6 `/center/users/:id` — User Detail & Edit

**API:**
- `GET /api/users/:id/`
- `PATCH /api/users/:id/` (requires `can_edit_user`)
- `DELETE /api/users/:id/` (requires `can_delete_user`)
- `PUT /api/users/:id/permissions/` (requires `can_manage_permissions`)

**Layout:** Two-panel card

**Left panel — Profile:**
- Name (editable field)
- Email (editable field)
- Role (select, editable)
- Active toggle
- Save button

**Right panel — Permissions:**
- Multi-select checkbox list (loaded from `GET /api/permissions/`)
- Checkboxes limited to allowed permissions for the user's role
- Save Permissions button

**Danger zone:**
- Delete User button (confirm modal)

---

### 3.7 `/center/student-requests` — Student Add Requests

**API:** `GET /api/student-requests/` (requires `can_view_student_requests`)

**Toolbar:**
- Filter by status (All | Pending | Approved | Rejected)

**Table columns:**
| Column | Description |
|--------|-------------|
| Student Name | Requested student name |
| Grade | Student grade |
| Parent Name | Parent's display name |
| Parent Email | Parent's email |
| Status | Badge |
| Submitted At | Date |
| Actions | Approve / Reject (Pending only) |

**Approve action:**
- `POST /api/student-requests/:id/approve/`
- On approval, backend creates `Student` record with generated credentials

**Reject action:**
- `POST /api/student-requests/:id/reject/`

---

## 4. Teacher Dashboard

> Role: `teacher` — creates and manages subject groups, lessons, and sections

### 4.1 `/teacher/dashboard` — Overview

**API:** `GET /api/me/`, `GET /api/content/subject-groups/`

**Layout:** Sidebar + content area

**Sidebar links:**
- Dashboard
- My Content
- Subject Groups

**Dashboard cards:**
- Total subject groups
- Total published lessons
- Total draft lessons

---

### 4.2 `/teacher/content` — Subject Group List

**API:** `GET /api/content/subject-groups/`

**Layout:** Grid of cards (3 columns on desktop, 1 on mobile)

**Toolbar:**
- "New Subject Group" button
- Filter by track (All | Arabic | Quran | Culture)
- Filter by status (All | Active | Inactive)

**Subject Group Card:**
```
┌─────────────────────────────┐
│ [Track Badge]  [Active badge]│
│                              │
│  Title                       │
│  Description (truncated)     │
│                              │
│  Lessons: 5   Files: 2       │
│                              │
│  [Edit]  [Manage Lessons]    │
└─────────────────────────────┘
```

---

### 4.3 Subject Group Create / Edit Modal

**API:**
- `POST /api/content/subject-groups/`
- `PATCH /api/content/subject-groups/:id/`

**Fields:**
- Title (input)
- Subject Track (select: Arabic | Quran | Culture)
- Description (textarea)
- Sort Order (number input)
- Active (toggle)

---

### 4.4 `/teacher/content/:groupId` — Subject Group Detail

**API:**
- `GET /api/content/subject-groups/:id/`
- `GET /api/content/subject-groups/:id/lessons/`
- `GET /api/content/subject-groups/:id/files/`

**Layout:** Two-tab layout

**Tab 1: Lessons**
- Sortable list of lessons (drag & drop, calls `/lessons/reorder/`)
- Each lesson row: title, published badge, created date, Edit / Open buttons
- "New Lesson" button

**Tab 2: Book Files**
- List of attached book files with type icon (PDF / Doc / Image / Audio)
- Each file: title, file type badge, upload date, Download / Delete buttons
- "Upload File" button (file picker + title input)

---

### 4.5 `/teacher/content/:groupId/lessons/:lessonId` — Lesson Editor

**API:**
- `GET /api/content/lessons/:id/` (returns full section tree)
- `PATCH /api/content/lessons/:id/`
- `POST /api/content/lessons/:id/sections/`
- `PATCH /api/content/sections/:id/`
- `DELETE /api/content/sections/:id/`
- `POST /api/content/lessons/:id/sections/reorder/`
- `POST /api/content/sections/:id/children/reorder/`
- `POST /api/content/media/` (image uploads)

**Layout:** Full-width editor — header bar + section tree

**Header bar:**
- Lesson title (inline editable)
- Published toggle (draft/published)
- Back button → subject group
- Save button

**Section Tree (left panel or inline):**
- Hierarchical, collapsible tree of sections
- Drag-and-drop reorder at each level
- Add section button at root and under each parent
- Each node shows type badge and title

**Section Editor (right panel or inline below):**

| Section Type | Editor |
|---|---|
| `title` | Title text input + depth selector |
| `content` | Rich text editor (TipTap / Quill) with image upload |
| `exercise` | SurveyJS form builder (JSON output saved to `content_body`) |

**Section form fields:**
- Type (select: Title | Content | Exercise)
- Title (text input)
- Content Body (rendered based on type above)
- Active toggle
- Delete button (confirm)

---

## 5. Parent Dashboard

> Role: `parent` — manages students and views published content

### 5.1 `/parent/dashboard` — Overview

**API:** `GET /api/me/`, `GET /api/students/`

**Sidebar links:**
- Dashboard
- My Students
- Content Library

**Dashboard cards:**
- Total students
- Pending student requests

---

### 5.2 `/parent/students` — My Students

**API:** `GET /api/students/` (requires `can_view_students`)

**Layout:** Card grid

**Student Card:**
```
┌──────────────────────────┐
│  [Avatar/Initial]        │
│  Student Name            │
│  Grade: 5                │
│  Username: stu_abc123    │
└──────────────────────────┘
```

**"Add Student" button:**
- Opens modal to submit student request
- `POST /api/student-requests/`
- Fields: Student Name, Grade
- On submit → success message "Request submitted, pending admin approval"

---

### 5.3 `/parent/content` — Content Library (Published)

**API:**
- `GET /api/content/published/subject-groups/`
- `GET /api/content/published/subject-groups/:id/lessons/`
- `GET /api/content/published/lessons/:id/`

**Layout:** Track tabs + subject group cards

**Track Tabs:** All | Arabic | Quran | Culture

**Subject Group Card:**
- Title, track badge, lesson count
- Click → lesson list for that group

**Lesson List:**
- Title, published date
- Click → lesson viewer

**Lesson Viewer (`/parent/content/:groupId/lessons/:lessonId`):**
- Renders section tree read-only
- `title` sections → styled heading
- `content` sections → rendered HTML
- `exercise` sections → SurveyJS read-only / interactive form
- No edit controls

---

## 6. Student Portal

> Separate login flow — `Student` model (not a Django user)

### 6.1 `/student/dashboard` — Student Home

**Layout:** Minimal, student-friendly

**Content:**
- Welcome message with student name
- Grade badge
- Link to content (if content access is implemented in future)

---

## 7. Shared Components

### 7.1 Layout Shell

```
┌────────────────────────────────────────────┐
│  [Logo]         Top Nav         [User Menu] │
├──────────┬─────────────────────────────────┤
│          │                                  │
│ Sidebar  │   Main Content Area              │
│  (nav)   │                                  │
│          │                                  │
└──────────┴─────────────────────────────────┘
```

**Top Nav:**
- Logo (left)
- Page breadcrumb (center)
- User avatar + name + logout (right)

**Sidebar:**
- Role-aware navigation links (rendered based on user role)
- Collapsible on mobile (hamburger)

---

### 7.2 Role Badge

Consistent color-coded badge across all tables and cards:

| Role | Color |
|---|---|
| Admin | Red |
| Center Admin | Purple |
| Teacher | Blue |
| Parent | Green |

---

### 7.3 Status Badge

| Status | Color |
|---|---|
| Active / Approved / Published | Green |
| Inactive / Rejected | Red |
| Pending / Draft | Yellow/Orange |
| Used | Gray |
| Expired | Dark Red |

---

### 7.4 Confirm Dialog

Reusable modal used before any destructive action (delete, reject, approve):
- Title: e.g. "Delete User?"
- Body: brief description of what will happen
- Buttons: Cancel (secondary) | Confirm (primary/danger)

---

### 7.5 Toast / Notification System

- Success toast (green) on successful create/update/delete
- Error toast (red) on API failure with error message
- Auto-dismiss after 4 seconds

---

### 7.6 Permission Guard (Frontend)

Wrapper component/HOC that:
1. Reads user role and permissions from auth store
2. Renders children only if user has required permission
3. Otherwise renders `null` or a disabled state

Used to conditionally show/hide buttons (e.g. "Delete" only if `can_delete_user`).

---

### 7.7 Route Guard

- Unauthenticated users → redirect `/login`
- Authenticated users accessing wrong role's routes → redirect `/403`
- Invalid routes → redirect `/404`

---

## 8. Access Control Matrix

| Page / Feature | Admin | Center Admin | Teacher | Parent | Student |
|---|:---:|:---:|:---:|:---:|:---:|
| `/login` | ✓ | ✓ | ✓ | ✓ | — |
| `/student-login` | — | — | — | — | ✓ |
| `/register/:token` | ✓ | ✓ | ✓ | ✓ | — |
| View Invitations | ✓ | ✓ | — | — | — |
| Create Invitation | ✓ | ✓ | — | — | — |
| View Registration Requests | ✓ | ✓ | — | — | — |
| Approve/Reject Requests | ✓ | ✓ | — | — | — |
| View Users | ✓ | ✓ | — | — | — |
| Edit/Delete Users | ✓ | ✓ | — | — | — |
| Manage Permissions | ✓ | ✓ | — | — | — |
| Manage Content | ✓ | — | ✓ | — | — |
| View Published Content | ✓ | ✓ | ✓ | ✓ | — |
| View My Students | — | — | — | ✓ | — |
| Add Student Request | — | — | — | ✓ | — |
| View/Approve Student Requests | ✓ | ✓ | — | — | — |
| Student Portal | — | — | — | — | ✓ |

---

## 9. Data Flow Summary

### Registration Flow
```
Admin sends invitation
    → Recipient gets link /register/:token
    → Fills form → POST /api/register/
    → RegistrationRequest created (status: pending)
    → Center Admin reviews /center/registration-requests
    → Approves → CustomUser activated
    → User can now login
```

### Student Add Flow
```
Parent logs in → /parent/students
    → Clicks "Add Student" → POST /api/student-requests/
    → Center Admin sees request in /center/student-requests
    → Approves → Student record created with credentials
    → Parent sees student in list with username
```

### Content Publish Flow
```
Teacher creates SubjectGroup
    → Adds Lessons
    → Adds Sections (title / content / exercise)
    → Toggles lesson to Published
    → Parent/Teacher can view via /published/ endpoints
```

---

## Notes for Implementation

- **RTL Support:** Use CSS `dir="rtl"` toggle; Arabic and Quran tracks likely need RTL layout.
- **Rich Text Editor:** TipTap or Quill recommended for `content` sections; must support image upload to `POST /api/content/media/`.
- **Exercise Builder:** SurveyJS Creator for the teacher editor; SurveyJS Runner for parent/student viewer.
- **Drag & Drop:** Use `dnd-kit` or `react-beautiful-dnd` for lesson and section reordering.
- **State Management:** Redux Toolkit or Zustand for auth state and permission caching.
- **API Client:** Axios with request interceptor to attach Bearer token from storage.
- **Token Refresh:** DRF token auth is non-expiring by default; handle 401 → redirect to login.
- **File Uploads:** Multipart form data for book files and media uploads; show progress bar.
