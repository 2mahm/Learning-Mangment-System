// Shared primitives + tiny stage shells for phone / tablet / desktop

const Stack = ({ children, gap = 12, dir = "col", align, justify, wrap, style, ...rest }) => (
  <div style={{
    display: "flex",
    flexDirection: dir === "row" ? "row" : "column",
    gap,
    alignItems: align,
    justifyContent: justify,
    flexWrap: wrap ? "wrap" : "nowrap",
    ...style,
  }} {...rest}>{children}</div>
);

const Pill = ({ children, color = "var(--primary)", size = "md", style }) => {
  const pad = size === "sm" ? "4px 10px" : size === "lg" ? "10px 18px" : "6px 14px";
  const fs = size === "sm" ? 12 : size === "lg" ? 16 : 13;
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      background: color, color: "#fff", padding: pad, borderRadius: 999,
      fontFamily: "var(--display-font)", fontWeight: 700, fontSize: fs,
      ...style,
    }}>{children}</span>
  );
};

const Tag = ({ children, color = "var(--primary)", style }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 6,
    background: `color-mix(in oklab, ${color} 15%, white)`,
    color, padding: "5px 12px", borderRadius: 999,
    fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 12,
    ...style,
  }}>{children}</span>
);

const ProgressBar = ({ value = 0, color = "var(--primary)", height = 14, bg = "rgba(0,0,0,.08)" }) => (
  <div style={{ background: bg, height, borderRadius: 999, overflow: "hidden", position: "relative" }}>
    <div style={{
      height: "100%", width: `${Math.max(0, Math.min(100, value))}%`,
      background: color, borderRadius: 999,
      transition: "width .4s cubic-bezier(.2,.9,.3,1.2)",
      boxShadow: "inset 0 -3px 0 rgba(0,0,0,.12), inset 0 3px 0 rgba(255,255,255,.25)",
    }} />
  </div>
);

const StarRow = ({ count = 3, total = 3, size = 22 }) => (
  <span style={{ display: "inline-flex", gap: 2 }}>
    {Array.from({ length: total }).map((_, i) => (
      <Icon key={i} name="star" size={size} color={i < count ? "var(--yellow)" : "rgba(0,0,0,.12)"} />
    ))}
  </span>
);

// PhoneFrame — a non-realistic minimal mobile shell
const PhoneFrame = ({ children, label, width = 360, height = 720 }) => (
  <div data-screen-label={label} style={{
    width, height,
    background: "var(--bg)",
    borderRadius: 44,
    border: "10px solid #1A1B3A",
    boxShadow: "0 20px 50px rgba(0,0,0,.3)",
    overflow: "hidden",
    position: "relative",
    fontFamily: "var(--body-font)",
    color: "var(--ink)",
    flex: "0 0 auto",
  }}>
    <div style={{
      position: "absolute", top: 8, left: "50%", transform: "translateX(-50%)",
      width: 110, height: 24, background: "#1A1B3A", borderRadius: 999, zIndex: 10,
    }} />
    <div style={{ height: "100%", overflowY: "auto", overflowX: "hidden", paddingTop: 36 }}>
      {children}
    </div>
  </div>
);

const TabletFrame = ({ children, label, width = 820, height = 600 }) => (
  <div data-screen-label={label} style={{
    width, height,
    background: "var(--bg)",
    borderRadius: 28,
    border: "10px solid #1A1B3A",
    boxShadow: "0 20px 50px rgba(0,0,0,.3)",
    overflow: "hidden",
    position: "relative",
    fontFamily: "var(--body-font)",
    color: "var(--ink)",
    flex: "0 0 auto",
  }}>
    <div style={{ height: "100%", overflowY: "auto", overflowX: "hidden" }}>
      {children}
    </div>
  </div>
);

const DesktopFrame = ({ children, label, width = 1100, height = 700 }) => {
  const wrapRef = React.useRef(null);
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const measure = () => {
      const el = wrapRef.current;
      if (!el) return;
      const avail = el.parentElement ? el.parentElement.clientWidth - 8 : window.innerWidth - 40;
      setScale(Math.min(1, avail / width));
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [width]);
  return (
    <div ref={wrapRef} style={{
      width: width * scale, height: height * scale, flex: "0 0 auto",
    }}>
      <div data-screen-label={label} style={{
        width, height,
        transform: `scale(${scale})`,
        transformOrigin: "top left",
        background: "var(--bg)",
        borderRadius: 16,
        border: "1px solid rgba(0,0,0,.08)",
        boxShadow: "0 20px 50px rgba(0,0,0,.18)",
        overflow: "hidden",
        position: "relative",
        fontFamily: "var(--body-font)",
        color: "var(--ink)",
      }}>
        <div style={{
          height: 36, background: "#F2EEE2", display: "flex", alignItems: "center", padding: "0 14px",
          borderBottom: "1px solid rgba(0,0,0,.06)",
        }}>
          <div style={{ display: "flex", gap: 6 }}>
            <span style={{ width: 12, height: 12, borderRadius: 6, background: "#FF6058" }} />
            <span style={{ width: 12, height: 12, borderRadius: 6, background: "#FFBD2D" }} />
            <span style={{ width: 12, height: 12, borderRadius: 6, background: "#28C840" }} />
          </div>
          <div style={{ marginInlineStart: "auto", fontSize: 12, color: "var(--ink-soft)", fontWeight: 700 }}>kiddo.app — {label}</div>
        </div>
        <div style={{ height: "calc(100% - 36px)", overflow: "auto" }}>
          {children}
        </div>
      </div>
    </div>
  );
};

window.Stack = Stack;
window.Pill = Pill;
window.Tag = Tag;
window.ProgressBar = ProgressBar;
window.StarRow = StarRow;
window.PhoneFrame = PhoneFrame;
window.TabletFrame = TabletFrame;
window.DesktopFrame = DesktopFrame;
