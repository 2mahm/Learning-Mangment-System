// TEACHER — multi-page dashboard

const TEACHER_STUDENTS = [
  { name: "Yasmine", glyph: "🦊", color: "#FF8A3D", progress: 86, lastActive: "5m", status: "ok",   age: 4 },
  { name: "Omar",    glyph: "🐼", color: "#4CC9F0", progress: 74, lastActive: "1h", status: "ok",   age: 5 },
  { name: "Layla",   glyph: "🐰", color: "#FF6B9D", progress: 92, lastActive: "20m", status: "star", age: 4 },
  { name: "Khaled",  glyph: "🦖", color: "#4CD471", progress: 45, lastActive: "2d", status: "help", age: 5 },
  { name: "Sara",    glyph: "🦉", color: "#8B5CF6", progress: 68, lastActive: "1d", status: "ok",   age: 4 },
  { name: "Ahmad",   glyph: "🦁", color: "#FFD23F", progress: 38, lastActive: "5d", status: "help", age: 5 },
  { name: "Noor",    glyph: "🐱", color: "#FF9FC7", progress: 81, lastActive: "30m", status: "ok",   age: 5 },
  { name: "Zaid",    glyph: "🐻", color: "#FFC94D", progress: 55, lastActive: "3d", status: "ok",   age: 4 },
];

const TeacherSidebar = ({ T, lang, dir, page, setPage }) => {
  const items = [
    { id: "classroom", label: T("classroom"),     icon: "home" },
    { id: "students",  label: T("students"),      icon: "users" },
    { id: "assign",    label: T("assignLesson"),  icon: "book" },
    { id: "reports",   label: lang === "ar" ? "التقارير" : "Reports", icon: "chart" },
    { id: "settings",  label: T("settings"),      icon: "settings" },
  ];
  return (
    <aside style={{
      width: 220, background: "var(--surface)", borderInlineEnd: "1px solid rgba(0,0,0,.06)",
      padding: "20px 14px", display: "flex", flexDirection: "column", gap: 4,
    }}>
      <Stack dir="row" gap={8} align="center" style={{ marginBottom: 18, padding: "0 4px" }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: "linear-gradient(135deg, var(--primary), var(--pink))",
          display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
          fontFamily: "var(--display-font)", fontWeight: 800,
        }}>K</div>
        <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18 }}>Kiddo</div>
      </Stack>
      {items.map((i) => (
        <button key={i.id} onClick={() => setPage(i.id)} style={{
          display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", border: "none",
          background: page === i.id ? "color-mix(in oklab, var(--primary) 12%, white)" : "transparent",
          color: page === i.id ? "var(--primary)" : "var(--ink-soft)",
          borderRadius: 12, cursor: "pointer", fontFamily: "var(--body-font)", fontSize: 14, fontWeight: 700,
          textAlign: dir === "rtl" ? "right" : "left",
        }}>
          <Icon name={i.icon} size={20} />
          <span>{i.label}</span>
        </button>
      ))}
    </aside>
  );
};

const TeacherClassroom = ({ T, lang, dir }) => (
  <div>
    <PageHeader
      title={lang === "ar" ? "روضة المرح ٢" : "Happy Class 2A"}
      sub={`${TEACHER_STUDENTS.length} ${T("students")} · ${lang === "ar" ? "السنة الأولى" : "Grade 1"}`}
      actions={<>
        <button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}><Icon name="search" size={16} /></button>
        <button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}>
          <Icon name="plus" size={16} color="#fff" /> {T("assignLesson")}
        </button>
      </>}
    />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
      {[
        { l: T("students"), v: 24, c: "var(--primary)", i: "users" },
        { l: T("avgScore"), v: "78%", c: "var(--green)", i: "trophy" },
        { l: lang === "ar" ? "الدروس" : "Active lessons", v: 12, c: "var(--accent)", i: "book" },
        { l: T("needsHelp"), v: 3, c: "var(--red)", i: "bell" },
      ].map((s, i) => (
        <div key={i} className="card" style={{ padding: 16 }}>
          <Stack dir="row" align="center" gap={12}>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: `color-mix(in oklab, ${s.c} 18%, white)`, color: s.c,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}><Icon name={s.i} size={20} /></div>
            <div>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 22, fontWeight: 800, lineHeight: 1 }}>{s.v}</div>
              <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{s.l}</div>
            </div>
          </Stack>
        </div>
      ))}
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14 }}>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "أحدث النشاطات" : "Recent activity"}</h3>
        <Stack gap={8}>
          {TEACHER_STUDENTS.slice(0, 5).map((s, i) => (
            <Stack key={i} dir="row" gap={10} align="center" style={{
              padding: "8px 10px", background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 12,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: "50%", background: s.color,
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
              }}>{s.glyph}</div>
              <div style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{s.name}</div>
              <span style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{s.lastActive}</span>
              <Pill color={s.progress >= 80 ? "var(--green)" : "var(--primary)"} size="sm">{s.progress}%</Pill>
            </Stack>
          ))}
        </Stack>
      </div>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "الواجبات القادمة" : "Upcoming"}</h3>
        <Stack gap={8}>
          {[
            { t: lang === "ar" ? "حروف D-F" : "Letters D-F", due: lang === "ar" ? "غدًا" : "Tomorrow", c: "var(--accent)" },
            { t: lang === "ar" ? "أرقام 11-20" : "Numbers 11-20", due: lang === "ar" ? "الجمعة" : "Friday", c: "var(--primary)" },
            { t: lang === "ar" ? "ألوان قوس قزح" : "Rainbow colors", due: lang === "ar" ? "الإثنين" : "Monday", c: "var(--red)" },
          ].map((a, i) => (
            <Stack key={i} dir="row" gap={10} align="center" style={{
              padding: "10px 12px", background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 12,
            }}>
              <div style={{ width: 4, height: 32, background: a.c, borderRadius: 2 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{a.t}</div>
                <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{a.due}</div>
              </div>
            </Stack>
          ))}
        </Stack>
      </div>
    </div>
  </div>
);

const TeacherStudents = ({ T, lang, dir }) => {
  const [filter, setFilter] = React.useState("all");
  const filtered = TEACHER_STUDENTS.filter(s => filter === "all" || s.status === filter);
  return (
    <div>
      <PageHeader
        title={T("students")}
        sub={`${TEACHER_STUDENTS.length} ${lang === "ar" ? "طالبًا في الصفّ" : "students enrolled"}`}
        actions={<>
          <button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}><Icon name="search" size={16} /> {lang === "ar" ? "بحث" : "Search"}</button>
          <button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}><Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "إضافة" : "Invite"}</button>
        </>}
      />
      <Stack dir="row" gap={6} style={{ marginBottom: 14 }}>
        {[
          { id: "all", label: lang === "ar" ? "الكلّ" : "All", count: TEACHER_STUDENTS.length },
          { id: "star", label: lang === "ar" ? "متفوّق" : "Top", count: TEACHER_STUDENTS.filter(s => s.status === "star").length },
          { id: "ok",   label: lang === "ar" ? "بخير" : "On track", count: TEACHER_STUDENTS.filter(s => s.status === "ok").length },
          { id: "help", label: T("needsHelp"), count: TEACHER_STUDENTS.filter(s => s.status === "help").length },
        ].map(f => (
          <button key={f.id} onClick={() => setFilter(f.id)} style={{
            padding: "8px 14px", borderRadius: 999, border: "none", cursor: "pointer",
            background: filter === f.id ? "var(--ink)" : "var(--surface)",
            color: filter === f.id ? "var(--bg)" : "var(--ink-soft)",
            fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13,
          }}>{f.label} · {f.count}</button>
        ))}
      </Stack>
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
          <thead>
            <tr style={{ background: "color-mix(in oklab, var(--bg) 60%, white)" }}>
              {[lang === "ar" ? "الطالب" : "Student", lang === "ar" ? "العمر" : "Age", lang === "ar" ? "التقدّم" : "Progress", lang === "ar" ? "آخر نشاط" : "Last active", lang === "ar" ? "الحالة" : "Status", ""].map((h, i) => (
                <th key={i} style={{
                  textAlign: dir === "rtl" ? "right" : "left",
                  padding: "12px 18px", color: "var(--ink-soft)", fontWeight: 800, fontSize: 11,
                  textTransform: "uppercase", letterSpacing: ".05em",
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((s, i) => (
              <tr key={i} style={{ borderTop: "1px solid rgba(0,0,0,.04)" }}>
                <td style={{ padding: "12px 18px" }}>
                  <Stack dir="row" gap={10} align="center">
                    <div style={{ width: 34, height: 34, borderRadius: "50%", background: s.color,
                      display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>{s.glyph}</div>
                    <span style={{ fontWeight: 700 }}>{s.name}</span>
                  </Stack>
                </td>
                <td style={{ padding: "12px 18px", color: "var(--ink-soft)", fontWeight: 700 }}>{s.age}</td>
                <td style={{ padding: "12px 18px", minWidth: 180 }}>
                  <Stack dir="row" gap={10} align="center">
                    <div style={{ flex: 1 }}><ProgressBar value={s.progress} color={s.progress >= 80 ? "var(--green)" : s.progress >= 60 ? "var(--primary)" : "var(--red)"} height={8} /></div>
                    <span className="mono" style={{ fontWeight: 800, fontSize: 13, minWidth: 36 }}>{s.progress}%</span>
                  </Stack>
                </td>
                <td style={{ padding: "12px 18px", color: "var(--ink-soft)", fontWeight: 700 }}>{s.lastActive}</td>
                <td style={{ padding: "12px 18px" }}>
                  {s.status === "star" && <Tag color="var(--green)">★ {lang === "ar" ? "متفوّق" : "Top"}</Tag>}
                  {s.status === "ok"   && <Tag color="var(--accent)">{lang === "ar" ? "بخير" : "On track"}</Tag>}
                  {s.status === "help" && <Tag color="var(--red)">⚠ {T("needsHelp")}</Tag>}
                </td>
                <td style={{ padding: "12px 18px", textAlign: "end" }}>
                  <button style={{ background: "transparent", border: "none", color: "var(--primary)", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>{lang === "ar" ? "عرض" : "View"} →</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const TeacherAssign = ({ T, lang, dir }) => {
  const [selected, setSelected] = React.useState(["Yasmine", "Layla"]);
  const [lesson, setLesson] = React.useState(null);
  const lessons = [
    { id: 1, title: lang === "ar" ? "العدّ من ١ إلى ١٠" : "Counting 1–10", subject: "math", color: "var(--primary)", time: 8 },
    { id: 2, title: lang === "ar" ? "الحروف A-F" : "Letters A–F", subject: "reading", color: "var(--accent)", time: 6 },
    { id: 3, title: lang === "ar" ? "ألوان قوس قزح" : "Rainbow colors", subject: "art", color: "var(--red)", time: 10 },
    { id: 4, title: lang === "ar" ? "الحيوانات" : "Animal sounds", subject: "science", color: "var(--green)", time: 7 },
  ];
  const toggle = (n) => setSelected(s => s.includes(n) ? s.filter(x => x !== n) : [...s, n]);

  return (
    <div>
      <PageHeader title={T("assignLesson")} sub={lang === "ar" ? "اختر الدرس والطلاب" : "Pick a lesson and students"} />
      <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14 }}>
        <div className="card" style={{ padding: 18 }}>
          <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "اختر درسًا" : "Choose a lesson"}</h3>
          <Stack gap={8}>
            {lessons.map(l => (
              <button key={l.id} onClick={() => setLesson(l.id)} style={{
                display: "flex", alignItems: "center", gap: 12, padding: 12,
                background: lesson === l.id ? "color-mix(in oklab, var(--primary) 12%, white)" : "color-mix(in oklab, var(--bg) 60%, white)",
                border: lesson === l.id ? `2px solid var(--primary)` : "2px solid transparent",
                borderRadius: 14, cursor: "pointer", textAlign: dir === "rtl" ? "right" : "left",
              }}>
                <div style={{
                  width: 40, height: 40, borderRadius: 10, background: l.color, color: "#fff",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}><Icon name="play" size={20} color="#fff" /></div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{l.title}</div>
                  <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{T(l.subject)} · {l.time} min</div>
                </div>
                {lesson === l.id && <div style={{
                  width: 24, height: 24, borderRadius: "50%", background: "var(--primary)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}><Icon name="check" size={14} color="#fff" stroke={3} /></div>}
              </button>
            ))}
          </Stack>
          <h3 style={{ fontFamily: "var(--display-font)", margin: "20px 0 10px", fontSize: 15 }}>{lang === "ar" ? "موعد التسليم" : "Due date"}</h3>
          <Stack dir="row" gap={6} wrap>
            {[lang === "ar" ? "اليوم" : "Today", lang === "ar" ? "غدًا" : "Tomorrow", lang === "ar" ? "هذا الأسبوع" : "This week", lang === "ar" ? "مخصّص" : "Custom"].map((d, i) => (
              <button key={i} style={{
                padding: "8px 14px", borderRadius: 999, border: "none",
                background: i === 1 ? "var(--ink)" : "color-mix(in oklab, var(--bg) 60%, white)",
                color: i === 1 ? "var(--bg)" : "var(--ink)", fontWeight: 700, fontSize: 12, cursor: "pointer",
              }}>{d}</button>
            ))}
          </Stack>
        </div>
        <div className="card" style={{ padding: 18 }}>
          <Stack dir="row" justify="space-between" align="center" style={{ marginBottom: 12 }}>
            <h3 style={{ fontFamily: "var(--display-font)", margin: 0, fontSize: 15 }}>{lang === "ar" ? "اختَر الطلاب" : "Select students"}</h3>
            <button onClick={() => setSelected(selected.length === TEACHER_STUDENTS.length ? [] : TEACHER_STUDENTS.map(s => s.name))}
              style={{ background: "transparent", border: "none", color: "var(--primary)", fontWeight: 700, cursor: "pointer", fontSize: 12 }}>
              {selected.length === TEACHER_STUDENTS.length ? (lang === "ar" ? "مسح" : "Clear") : (lang === "ar" ? "تحديد الكلّ" : "Select all")}
            </button>
          </Stack>
          <Stack gap={6} style={{ maxHeight: 320, overflow: "auto" }}>
            {TEACHER_STUDENTS.map(s => (
              <Stack key={s.name} dir="row" gap={10} align="center" onClick={() => toggle(s.name)} style={{
                padding: "8px 10px", borderRadius: 10, cursor: "pointer",
                background: selected.includes(s.name) ? "color-mix(in oklab, var(--primary) 12%, white)" : "transparent",
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 6,
                  background: selected.includes(s.name) ? "var(--primary)" : "transparent",
                  border: "2px solid " + (selected.includes(s.name) ? "var(--primary)" : "color-mix(in oklab, var(--ink-soft) 30%, white)"),
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  {selected.includes(s.name) && <Icon name="check" size={12} color="#fff" stroke={4} />}
                </div>
                <div style={{ width: 28, height: 28, borderRadius: "50%", background: s.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>{s.glyph}</div>
                <span style={{ fontWeight: 700, fontSize: 13 }}>{s.name}</span>
              </Stack>
            ))}
          </Stack>
          <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid rgba(0,0,0,.06)" }}>
            <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700, marginBottom: 8 }}>
              {selected.length} {lang === "ar" ? "طالبًا محدّدًا" : "students selected"}
            </div>
            <button className="btn btn-primary" style={{ width: "100%", padding: "12px 16px", fontSize: 14 }}
              disabled={!lesson || !selected.length}>
              <Icon name="check" size={18} color="#fff" stroke={3} /> {lang === "ar" ? "تعيين الدرس" : "Assign lesson"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const TeacherReports = ({ T, lang, dir }) => (
  <div>
    <PageHeader
      title={lang === "ar" ? "التقارير" : "Reports"}
      sub={lang === "ar" ? "أداء الصفّ خلال الوقت" : "Class performance over time"}
      actions={<button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}>{lang === "ar" ? "تصدير PDF" : "Export PDF"}</button>}
    />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 14 }}>
      {[
        { l: lang === "ar" ? "متوسط الإنجاز" : "Avg completion", v: "78%", t: "+5%", c: "var(--green)" },
        { l: lang === "ar" ? "وقت في الأسبوع" : "Time this week", v: "14h", t: "+1.2h", c: "var(--primary)" },
        { l: lang === "ar" ? "دروس مكتملة" : "Lessons done", v: 142, t: "+22", c: "var(--accent)" },
        { l: lang === "ar" ? "معدّل الحضور" : "Attendance", v: "92%", t: "-2%", c: "var(--violet)" },
      ].map((s, i) => (
        <div key={i} className="card" style={{ padding: 16 }}>
          <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 800, textTransform: "uppercase", letterSpacing: ".05em" }}>{s.l}</div>
          <div style={{ fontFamily: "var(--display-font)", fontSize: 28, fontWeight: 800, marginTop: 4 }}>{s.v}</div>
          <div style={{ fontSize: 12, color: s.c, fontWeight: 800, marginTop: 2 }}>{s.t}</div>
        </div>
      ))}
    </div>
    <div className="card" style={{ padding: 20, marginBottom: 14 }}>
      <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 14px", fontSize: 16 }}>{lang === "ar" ? "متوسط الصفّ - ٤ أسابيع" : "Class average — 4 weeks"}</h3>
      <svg viewBox="0 0 600 180" width="100%" height="180" preserveAspectRatio="none">
        <defs>
          <linearGradient id="rep-grad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.4" />
            <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[40, 80, 120].map(y => <line key={y} x1="0" x2="600" y1={y} y2={y} stroke="rgba(0,0,0,.06)" strokeWidth="1" />)}
        <path d="M 0,140 L 86,110 L 172,120 L 258,80 L 344,90 L 430,55 L 516,65 L 600,40 L 600,180 L 0,180 Z" fill="url(#rep-grad)" />
        <path d="M 0,140 L 86,110 L 172,120 L 258,80 L 344,90 L 430,55 L 516,65 L 600,40" fill="none" stroke="var(--primary)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        {[[0,140],[86,110],[172,120],[258,80],[344,90],[430,55],[516,65],[600,40]].map(([x,y], i) => (
          <circle key={i} cx={x} cy={y} r="4" fill="#fff" stroke="var(--primary)" strokeWidth="3" />
        ))}
      </svg>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "أفضل الطلاب" : "Top students"}</h3>
        <Stack gap={6}>
          {[...TEACHER_STUDENTS].sort((a,b) => b.progress - a.progress).slice(0, 4).map((s, i) => (
            <Stack key={i} dir="row" gap={10} align="center" style={{ padding: "8px 10px", borderRadius: 10, background: "color-mix(in oklab, var(--bg) 60%, white)" }}>
              <span style={{ fontFamily: "var(--display-font)", fontWeight: 800, color: "var(--ink-soft)", width: 18 }}>{i+1}</span>
              <div style={{ width: 28, height: 28, borderRadius: "50%", background: s.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>{s.glyph}</div>
              <span style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{s.name}</span>
              <Pill color="var(--green)" size="sm">{s.progress}%</Pill>
            </Stack>
          ))}
        </Stack>
      </div>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "حسب المادّة" : "By subject"}</h3>
        <Stack gap={10}>
          {[
            { sub: "math", v: 82, color: "var(--primary)" },
            { sub: "reading", v: 76, color: "var(--accent)" },
            { sub: "science", v: 68, color: "var(--green)" },
            { sub: "art", v: 88, color: "var(--red)" },
          ].map((r, i) => (
            <div key={i}>
              <Stack dir="row" justify="space-between"><span style={{ fontWeight: 700, fontSize: 12 }}>{T(r.sub)}</span><span className="mono" style={{ fontWeight: 800, fontSize: 12 }}>{r.v}%</span></Stack>
              <ProgressBar value={r.v} color={r.color} height={8} />
            </div>
          ))}
        </Stack>
      </div>
    </div>
  </div>
);

const TeacherSettings = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("settings")} sub={lang === "ar" ? "تفضيلات المعلّم" : "Teacher preferences"} />
    <div className="card" style={{ padding: 0, overflow: "hidden", maxWidth: 600 }}>
      {[
        { i: "user",     l: lang === "ar" ? "الملف الشخصي" : "Profile", v: "Mrs. Sara" },
        { i: "bell",     l: lang === "ar" ? "الإشعارات" : "Notifications", v: lang === "ar" ? "مفعّلة" : "On" },
        { i: "users",    l: lang === "ar" ? "الصفوف" : "Classes", v: "3" },
        { i: "palette",  l: lang === "ar" ? "السمة" : "Theme", v: lang === "ar" ? "فاتح" : "Light" },
        { i: "speaker",  l: lang === "ar" ? "اللغة" : "Language", v: lang === "ar" ? "العربية" : "English" },
      ].map((row, i, arr) => (
        <div key={i} style={{
          display: "flex", alignItems: "center", gap: 14, padding: "14px 18px",
          borderBottom: i < arr.length - 1 ? "1px solid rgba(0,0,0,.05)" : "none",
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, background: "color-mix(in oklab, var(--primary) 15%, white)",
            color: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center",
          }}><Icon name={row.i} size={18} /></div>
          <div style={{ flex: 1, fontWeight: 700, fontSize: 14 }}>{row.l}</div>
          <div style={{ color: "var(--ink-soft)", fontWeight: 700, fontSize: 13 }}>{row.v}</div>
          <Icon name={dir === "rtl" ? "chevronL" : "chevron"} size={18} color="var(--ink-soft)" />
        </div>
      ))}
    </div>
  </div>
);

const TeacherDashboard = ({ T, lang, dir }) => {
  const [page, setPage] = React.useState("classroom");
  return (
    <div style={{ display: "flex", height: "100%", background: "var(--bg)", color: "var(--ink)" }}>
      <TeacherSidebar T={T} lang={lang} dir={dir} page={page} setPage={setPage} />
      <main style={{ flex: 1, padding: 22, overflow: "auto" }}>
        {page === "classroom" && <TeacherClassroom T={T} lang={lang} dir={dir} />}
        {page === "students"  && <TeacherStudents T={T} lang={lang} dir={dir} />}
        {page === "assign"    && <TeacherAssign T={T} lang={lang} dir={dir} />}
        {page === "reports"   && <TeacherReports T={T} lang={lang} dir={dir} />}
        {page === "settings"  && <TeacherSettings T={T} lang={lang} dir={dir} />}
      </main>
    </div>
  );
};

window.TeacherDashboard = TeacherDashboard;
