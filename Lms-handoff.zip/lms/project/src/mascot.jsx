// Kiddo mascot — a friendly fox-bear-blob creature.
// Two variants for the two directions.

const MascotA = ({ size = 120, mood = "happy" }) => (
  <svg viewBox="0 0 200 200" width={size} height={size} style={{ overflow: "visible" }}>
    {/* shadow */}
    <ellipse cx="100" cy="186" rx="60" ry="6" fill="rgba(0,0,0,.1)" />
    {/* body */}
    <path d="M40 110 C 40 60, 70 40, 100 40 C 130 40, 160 60, 160 110 L 160 150 C 160 175, 140 185, 100 185 C 60 185, 40 175, 40 150 Z"
      fill="#FFB45C" stroke="#2B1D47" strokeWidth="4" />
    {/* belly */}
    <ellipse cx="100" cy="135" rx="38" ry="32" fill="#FFE9C9" />
    {/* ears */}
    <path d="M55 60 L 45 35 L 75 50 Z" fill="#FFB45C" stroke="#2B1D47" strokeWidth="4" strokeLinejoin="round" />
    <path d="M145 60 L 155 35 L 125 50 Z" fill="#FFB45C" stroke="#2B1D47" strokeWidth="4" strokeLinejoin="round" />
    <path d="M58 55 L 53 42 L 68 49 Z" fill="#FF8A3D" />
    <path d="M142 55 L 147 42 L 132 49 Z" fill="#FF8A3D" />
    {/* cheeks */}
    <ellipse cx="60" cy="115" rx="10" ry="6" fill="#FF6B9D" opacity=".55" />
    <ellipse cx="140" cy="115" rx="10" ry="6" fill="#FF6B9D" opacity=".55" />
    {/* eyes */}
    {mood === "happy" ? (
      <>
        <path d="M70 95 Q 78 86 86 95" stroke="#2B1D47" strokeWidth="5" fill="none" strokeLinecap="round" />
        <path d="M114 95 Q 122 86 130 95" stroke="#2B1D47" strokeWidth="5" fill="none" strokeLinecap="round" />
      </>
    ) : mood === "wow" ? (
      <>
        <circle cx="78" cy="95" r="7" fill="#2B1D47" />
        <circle cx="122" cy="95" r="7" fill="#2B1D47" />
        <circle cx="80" cy="93" r="2" fill="#fff" />
        <circle cx="124" cy="93" r="2" fill="#fff" />
      </>
    ) : (
      <>
        <circle cx="78" cy="95" r="5" fill="#2B1D47" />
        <circle cx="122" cy="95" r="5" fill="#2B1D47" />
        <circle cx="79" cy="93" r="1.6" fill="#fff" />
        <circle cx="123" cy="93" r="1.6" fill="#fff" />
      </>
    )}
    {/* mouth */}
    {mood === "wow" ? (
      <ellipse cx="100" cy="118" rx="6" ry="8" fill="#2B1D47" />
    ) : (
      <path d="M88 115 Q 100 128 112 115" stroke="#2B1D47" strokeWidth="4.5" fill="none" strokeLinecap="round" />
    )}
    {/* arms */}
    <circle cx="36" cy="130" r="14" fill="#FFB45C" stroke="#2B1D47" strokeWidth="4" />
    <circle cx="164" cy="130" r="14" fill="#FFB45C" stroke="#2B1D47" strokeWidth="4" />
  </svg>
);

const MascotB = ({ size = 120, mood = "happy" }) => (
  <svg viewBox="0 0 200 200" width={size} height={size} style={{ overflow: "visible" }}>
    <ellipse cx="100" cy="186" rx="55" ry="5" fill="rgba(0,0,0,.08)" />
    {/* cloud-blob body */}
    <path d="M50 120 C 30 120, 30 90, 55 88 C 55 60, 100 50, 115 75 C 145 65, 165 95, 150 115 C 165 135, 140 165, 110 158 C 95 178, 55 175, 50 150 C 30 148, 30 128, 50 120 Z"
      fill="#C7D5FF" stroke="#1B2240" strokeWidth="3.5" />
    {/* face highlight */}
    <ellipse cx="100" cy="120" rx="42" ry="32" fill="#E8EFFF" />
    {/* cheeks */}
    <ellipse cx="62" cy="120" rx="9" ry="6" fill="#FF9FC7" opacity=".7" />
    <ellipse cx="138" cy="120" rx="9" ry="6" fill="#FF9FC7" opacity=".7" />
    {/* eyes */}
    <circle cx="80" cy="105" r="6" fill="#1B2240" />
    <circle cx="120" cy="105" r="6" fill="#1B2240" />
    <circle cx="82" cy="103" r="2" fill="#fff" />
    <circle cx="122" cy="103" r="2" fill="#fff" />
    {/* mouth */}
    <path d="M88 125 Q 100 138 112 125" stroke="#1B2240" strokeWidth="4" fill="none" strokeLinecap="round" />
    {/* tuft */}
    <path d="M95 50 Q 100 35 110 50" stroke="#1B2240" strokeWidth="3.5" fill="none" strokeLinecap="round" />
  </svg>
);

const Mascot = ({ direction = "A", size = 120, mood = "happy", float = false }) => {
  const M = direction === "B" ? MascotB : MascotA;
  return (
    <div className={float ? "anim-float" : ""} style={{ display: "inline-block" }}>
      <M size={size} mood={mood} />
    </div>
  );
};

window.Mascot = Mascot;
