// Main app — composes all roles into a single canvas

const { useState, useEffect, useMemo } = React;

const ROLES = [
  { id: "child",   label: "child",   icon: "smile" },
  { id: "parent",  label: "parent",  icon: "user" },
  { id: "teacher", label: "teacher", icon: "users" },
  { id: "admin",   label: "admin",   icon: "settings" },
];

const App = () => {
  const [tweaks, setTweaks] = useState(window.TWEAKS_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useState(false);
  const [role, setRole] = useState("child");
  const [profile, setProfile] = useState({ avatar: AVATARS[0], name: "Yasmine" });

  const T = useT(tweaks.language);
  const lang = tweaks.language;
  const dir = lang === "ar" ? "rtl" : "ltr";

  // Apply palette via CSS vars on the wrapper
  const palette = PALETTES[tweaks.palette] || PALETTES.default;
  const wrapStyle = {
    "--a-primary": palette.primary,
    "--a-primary-d": palette.primaryD,
    "--a-accent": palette.accent,
    "--b-primary": palette.primary,
    "--b-primary-d": palette.primaryD,
    "--b-accent": palette.accent,
  };

  // Tweaks <-> host bridge
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data?.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", handler);
  }, []);

  // Hide loader
  useEffect(() => {
    const el = document.getElementById("loading");
    if (el) el.style.display = "none";
  }, []);

  return (
    <div data-dir={tweaks.direction} data-theme={tweaks.theme} dir={dir} style={{
      minHeight: "100vh",
      background: "var(--bg)",
      color: "var(--ink)",
      fontFamily: "var(--body-font)",
      ...wrapStyle,
    }}>
      {/* Top header (canvas chrome) */}
      <header style={{
        position: "sticky", top: 0, zIndex: 40,
        background: "color-mix(in oklab, var(--bg) 85%, white)",
        backdropFilter: "blur(10px)",
        borderBottom: "1px solid rgba(0,0,0,.05)",
        padding: "14px 20px",
      }}>
        <Stack dir="row" justify="space-between" align="center">
          <Stack dir="row" gap={12} align="center">
            <div style={{
              width: 38, height: 38, borderRadius: 12,
              background: "linear-gradient(135deg, var(--primary), var(--pink))",
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
              fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18,
              boxShadow: "0 4px 0 rgba(0,0,0,.1)",
            }}>K</div>
            <div>
              <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18, lineHeight: 1 }}>
                Kiddo LMS
              </div>
              <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700, marginTop: 2 }}>
                {lang === "ar" ? "نموذج تفاعلي · اتجاهان" : "Interactive prototype · 2 directions"}
              </div>
            </div>
          </Stack>

          {/* Role switcher */}
          <Stack dir="row" gap={6}>
            {ROLES.map(r => (
              <button key={r.id} onClick={() => setRole(r.id)} style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "8px 14px", borderRadius: 999, border: "none", cursor: "pointer",
                background: role === r.id ? "var(--ink)" : "transparent",
                color: role === r.id ? "var(--bg)" : "var(--ink-soft)",
                fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13,
                transition: "all .15s",
              }}>
                <Icon name={r.icon} size={16} />
                {T(r.label)}
              </button>
            ))}
          </Stack>

          <Stack dir="row" gap={8} align="center">
            <span style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700 }}>
              {tweaks.direction === "A" ? "Crayon" : "Cloud"} · {lang.toUpperCase()}
            </span>
            <button onClick={() => setTweaksOpen(o => !o)} style={{
              width: 38, height: 38, borderRadius: 12, border: "none",
              background: tweaksOpen ? "var(--primary)" : "var(--surface)",
              color: tweaksOpen ? "#fff" : "var(--ink)",
              cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 3px 0 rgba(0,0,0,.08)",
            }}>
              <Icon name="settings" size={20} />
            </button>
          </Stack>
        </Stack>
      </header>

      {/* Canvas */}
      <div style={{ padding: "32px 20px 60px" }}>
        {role === "child" && (
          <ChildCanvas T={T} lang={lang} dir={dir} tweaks={tweaks} profile={profile} setProfile={setProfile} />
        )}
        {role === "parent"  && <ParentCanvas T={T} lang={lang} dir={dir} tweaks={tweaks} />}
        {role === "teacher" && <TeacherCanvas T={T} lang={lang} dir={dir} tweaks={tweaks} />}
        {role === "admin"   && <AdminCanvas T={T} lang={lang} dir={dir} tweaks={tweaks} />}
      </div>

      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} open={tweaksOpen} />
    </div>
  );
};

// ===== Canvas layouts per role =====

const SectionLabel = ({ children, n }) => (
  <Stack dir="row" align="center" gap={10} style={{ marginBottom: 16 }}>
    <span style={{
      width: 28, height: 28, borderRadius: 8, background: "var(--ink)", color: "var(--bg)",
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 14,
    }}>{n}</span>
    <span style={{ fontFamily: "var(--display-font)", fontSize: 18, fontWeight: 800, color: "var(--ink)" }}>{children}</span>
  </Stack>
);

const FrameLabel = ({ children }) => (
  <div style={{
    fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13,
    color: "var(--ink-soft)", marginTop: 10, textAlign: "center",
  }}>{children}</div>
);

// CHILD canvas — desktop dashboard
const ChildCanvas = ({ T, lang, dir, tweaks, profile, setProfile }) => {
  return (
    <div style={{ maxWidth: 1200, margin: "0 auto" }}>
      <SectionLabel n="01">{lang === "ar" ? "لوحة الطفل" : "Kids dashboard"}</SectionLabel>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <DesktopFrame label="Kids" width={1100} height={760}>
          <KidsDashboard T={T} lang={lang} dir={dir} tweaks={tweaks} profile={profile} />
        </DesktopFrame>
      </div>
    </div>
  );
};

// Inline router used inside frames — each phone shows its labeled screen as starting state
const ScreenRouter = ({ screen, T, lang, dir, tweaks, profile, setProfile }) => {
  return (
    <ChildApp
      T={T} lang={lang} dir={dir}
      mascot={tweaks.mascot}
      gam={tweaks.gamification}
      profile={profile}
      setProfile={setProfile}
      initialScreen={screen}
      key={screen + tweaks.direction + tweaks.language + tweaks.theme + tweaks.palette + tweaks.gamification + tweaks.mascot}
    />
  );
};

const ParentCanvas = ({ T, lang, dir, tweaks }) => (
  <div style={{ maxWidth: 1300, margin: "0 auto" }}>
    <SectionLabel n="01">{lang === "ar" ? "لوحة الوالدين" : "Parent dashboard"}</SectionLabel>
    <div style={{ display: "flex", justifyContent: "center" }}>
      <DesktopFrame label="Parent" width={1200} height={780}>
        <ParentDashboard T={T} lang={lang} dir={dir} />
      </DesktopFrame>
    </div>
  </div>
);

const TeacherCanvas = ({ T, lang, dir, tweaks }) => (
  <div style={{ maxWidth: 1300, margin: "0 auto" }}>
    <SectionLabel n="01">{lang === "ar" ? "لوحة المعلّم" : "Teacher dashboard"}</SectionLabel>
    <div style={{ display: "flex", justifyContent: "center" }}>
      <DesktopFrame label="Teacher" width={1200} height={780}>
        <TeacherDashboard T={T} lang={lang} dir={dir} />
      </DesktopFrame>
    </div>
  </div>
);

const AdminCanvas = ({ T, lang, dir, tweaks }) => (
  <div style={{ maxWidth: 1300, margin: "0 auto" }}>
    <SectionLabel n="01">{lang === "ar" ? "إدارة المدرسة" : "School admin"}</SectionLabel>
    <div style={{ display: "flex", justifyContent: "center" }}>
      <DesktopFrame label="Admin" width={1200} height={780}>
        <AdminDashboard T={T} lang={lang} dir={dir} />
      </DesktopFrame>
    </div>
  </div>
);

// Mount
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
