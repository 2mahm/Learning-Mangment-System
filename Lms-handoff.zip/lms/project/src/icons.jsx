// Chunky SVG icons — friendly, kid-readable
const Icon = ({ name, size = 28, color = "currentColor", stroke = 2.4 }) => {
  const common = {
    width: size, height: size, viewBox: "0 0 24 24",
    fill: "none", stroke: color, strokeWidth: stroke,
    strokeLinecap: "round", strokeLinejoin: "round",
  };
  const paths = {
    home: <><path d="M3 11l9-8 9 8" /><path d="M5 10v10h14V10" /><path d="M10 20v-6h4v6" /></>,
    book: <><path d="M4 5a2 2 0 0 1 2-2h12v16H6a2 2 0 0 0-2 2V5z" /><path d="M4 19a2 2 0 0 1 2-2h12" /></>,
    play: <><path d="M7 5l12 7-12 7V5z" fill={color} /></>,
    star: <path d="M12 3l2.7 5.7 6.3.9-4.6 4.4 1.1 6.3L12 17.8 6.5 20.3l1.1-6.3L3 9.6l6.3-.9L12 3z" fill={color} stroke="none" />,
    heart: <path d="M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.7A4 4 0 0 1 19 11c0 5.6-7 10-7 10z" fill={color} stroke="none" />,
    smile: <><circle cx="12" cy="12" r="9" /><circle cx="9" cy="10" r=".8" fill={color} /><circle cx="15" cy="10" r=".8" fill={color} /><path d="M8 14a4 4 0 0 0 8 0" /></>,
    bell: <><path d="M6 17V11a6 6 0 0 1 12 0v6" /><path d="M4 17h16" /><path d="M10 21a2 2 0 0 0 4 0" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4.9a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.5a7 7 0 0 0-2 1.2L5 5.8l-2 3.4 2 1.6A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.6 2 3.4 2.4-.9c.6.5 1.3.9 2 1.2L10 21h4l.5-2.5c.7-.3 1.4-.7 2-1.2l2.4.9 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z" /></>,
    chevron: <path d="M9 6l6 6-6 6" />,
    chevronL: <path d="M15 6l-6 6 6 6" />,
    check: <path d="M5 12l5 5L20 7" strokeWidth="3" />,
    x: <path d="M6 6l12 12M6 18L18 6" strokeWidth="3" />,
    sparkle: <><path d="M12 3v4M12 17v4M3 12h4M17 12h4" /><path d="M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6" /></>,
    trophy: <><path d="M8 4h8v5a4 4 0 0 1-8 0V4z" /><path d="M5 5v2a3 3 0 0 0 3 3M19 5v2a3 3 0 0 1-3 3" /><path d="M9 14h6v3H9zM7 20h10" /></>,
    flame: <><path d="M12 3s4 4 4 8a4 4 0 1 1-8 0c0-2 1-3 1-3s0 2 2 2 1-3 1-7z" fill={color} stroke="none" /></>,
    coin: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="6" /><path d="M12 9v6M9 12h6" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    users: <><circle cx="9" cy="8" r="3.5" /><path d="M3 21a6 6 0 0 1 12 0" /><circle cx="17" cy="9" r="3" /><path d="M15 21a5 5 0 0 1 7 0" /></>,
    plus: <path d="M12 5v14M5 12h14" strokeWidth="3" />,
    search: <><circle cx="11" cy="11" r="6" /><path d="M16 16l5 5" /></>,
    mic: <><rect x="9" y="3" width="6" height="12" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></>,
    headphone: <><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><path d="M4 14h3v6H4zM17 14h3v6h-3z" /></>,
    lock: <><rect x="5" y="11" width="14" height="9" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>,
    palette: <><path d="M12 3a9 9 0 1 0 0 18c1 0 2-1 2-2s-1-1-1-2 1-2 2-2h2a4 4 0 0 0 4-4c0-4-4-8-9-8z" /><circle cx="7.5" cy="11.5" r="1" fill={color} /><circle cx="10.5" cy="7.5" r="1" fill={color} /><circle cx="15.5" cy="8.5" r="1" fill={color} /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    chart: <><path d="M4 20V8M10 20v-6M16 20V4M22 20H2" /></>,
    rocket: <><path d="M12 3c4 4 6 8 5 13l-5-2-5 2c-1-5 1-9 5-13z" /><circle cx="12" cy="10" r="1.5" /><path d="M9 18l-2 3M15 18l2 3" /></>,
    abc: <><path d="M3 18l3-9 3 9M4 15h4" /><path d="M11 9h3a2 2 0 0 1 0 4h-3v5h3a2 2 0 0 0 0-4" /><path d="M22 11a3 3 0 0 0-6 0v4a3 3 0 0 0 6 0" /></>,
    code: <><path d="M9 6l-5 6 5 6M15 6l5 6-5 6" /></>,
    leaf: <><path d="M5 19c0-8 6-14 14-14 0 8-6 14-14 14z" /><path d="M5 19l9-9" /></>,
    moon: <path d="M20 14a8 8 0 1 1-9-9 7 7 0 0 0 9 9z" fill={color} stroke="none" />,
    sun: <><circle cx="12" cy="12" r="4" fill={color} stroke="none" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2" /></>,
    quran: <><path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3V4z" /><path d="M9 9h7M9 12h5M9 15h7" /></>,
    paint: <><rect x="4" y="3" width="14" height="6" rx="1.5" /><path d="M11 9v3h6v3a3 3 0 0 1-3 3h-1v3h-2v-3h-1a3 3 0 0 1-3-3" /></>,
    flask: <><path d="M9 3h6M10 3v5L5 19a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-11V3" /><path d="M7 14h10" /></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    speaker: <><path d="M5 9h4l5-4v14l-5-4H5z" /><path d="M17 9a4 4 0 0 1 0 6" /></>,
    fire: <path d="M12 2s5 4 5 9-3 8-5 8-5-3-5-8c0-2 1-3 1-3s0 2 2 2-1-4 2-8z" fill={color} stroke="none" />,
  };
  return <svg {...common}>{paths[name] || null}</svg>;
};

window.Icon = Icon;
