// CHILD-FACING SCREENS: onboarding, home, course browser, lesson, quiz, rewards, profile
// Designed for ages 2-5 primarily: huge touch targets, illustrations, minimal text.

const SUBJECTS = [
  { id: "math",    icon: "abc",    label: "math",    color: "var(--primary)", emoji: "1+1" },
  { id: "reading", icon: "book",   label: "reading", color: "var(--accent)",  emoji: "Aa" },
  { id: "science", icon: "flask",  label: "science", color: "var(--green)",   emoji: "🔬" },
  { id: "coding",  icon: "code",   label: "coding",  color: "var(--violet)",  emoji: "</>" },
  { id: "arabic",  icon: "abc",    label: "arabic",  color: "var(--pink)",    emoji: "أ" },
  { id: "english", icon: "abc",    label: "english", color: "var(--yellow)",  emoji: "A" },
  { id: "art",     icon: "paint",  label: "art",     color: "var(--red)",     emoji: "🎨" },
  { id: "quran",   icon: "quran",  label: "quran",   color: "var(--green)",   emoji: "ﷲ" },
];

const AVATARS = [
  { id: "fox", color: "#FF8A3D", glyph: "🦊" },
  { id: "bear", color: "#FFC94D", glyph: "🐻" },
  { id: "cat", color: "#FF9FC7", glyph: "🐱" },
  { id: "owl", color: "#8B5CF6", glyph: "🦉" },
  { id: "rabbit", color: "#FF6B9D", glyph: "🐰" },
  { id: "panda", color: "#4CC9F0", glyph: "🐼" },
  { id: "dino", color: "#4CD471", glyph: "🦖" },
  { id: "lion", color: "#FFD23F", glyph: "🦁" },
];

// ========= ONBOARDING =========
const Onboarding = ({ T, lang, dir, mascot, onDone }) => {
  const [step, setStep] = React.useState(0);
  const [avatar, setAvatar] = React.useState(null);
  const [name, setName] = React.useState("");

  return (
    <div style={{
      height: "100%", padding: "20px 18px 24px",
      background: `linear-gradient(180deg, var(--bg) 0%, color-mix(in oklab, var(--primary) 12%, var(--bg)) 100%)`,
      display: "flex", flexDirection: "column",
    }}>
      {step === 0 && (
        <Stack gap={20} align="center" justify="center" style={{ flex: 1, textAlign: "center" }}>
          {mascot && <Mascot direction={dir} size={140} float />}
          <h1 style={{ fontFamily: "var(--display-font)", fontSize: 36, margin: 0, color: "var(--ink)" }}>{T("welcome")}</h1>
          <p style={{ color: "var(--ink-soft)", fontSize: 18, margin: 0, fontWeight: 600 }}>{T("welcomeSub")}</p>
          <button className="btn btn-primary btn-big" onClick={() => setStep(1)} style={{ width: "100%", marginTop: 10 }}>
            {T("letsGo")} <Icon name="chevron" size={22} color="#fff" />
          </button>
        </Stack>
      )}

      {step === 1 && (
        <Stack gap={18} style={{ flex: 1 }}>
          <h2 style={{ fontFamily: "var(--display-font)", fontSize: 26, margin: "10px 0 0", color: "var(--ink)" }}>{T("chooseAvatar")}</h2>
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: 14,
          }}>
            {AVATARS.map(a => (
              <button key={a.id} onClick={() => setAvatar(a)} style={{
                background: `color-mix(in oklab, ${a.color} 30%, white)`,
                border: avatar?.id === a.id ? `4px solid ${a.color}` : "4px solid transparent",
                borderRadius: 24,
                padding: "18px 0",
                fontSize: 56,
                cursor: "pointer",
                boxShadow: "0 5px 0 rgba(0,0,0,.08)",
                transition: "transform .15s",
                transform: avatar?.id === a.id ? "scale(1.04)" : "scale(1)",
              }} className="anim-wiggle">
                {a.glyph}
              </button>
            ))}
          </div>
          <button className="btn btn-primary btn-big" disabled={!avatar} onClick={() => setStep(2)} style={{
            width: "100%", marginTop: "auto", opacity: avatar ? 1 : 0.4,
          }}>
            {T("next")}
          </button>
        </Stack>
      )}

      {step === 2 && (
        <Stack gap={18} style={{ flex: 1 }}>
          <h2 style={{ fontFamily: "var(--display-font)", fontSize: 26, margin: "10px 0 0", color: "var(--ink)" }}>{T("chooseName")}</h2>
          <div style={{
            background: "var(--surface)", borderRadius: 24, padding: 20, textAlign: "center",
            boxShadow: "var(--card-sh)",
          }}>
            <div style={{
              width: 100, height: 100, margin: "0 auto 14px",
              background: avatar.color, borderRadius: "50%",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 56, boxShadow: "0 5px 0 rgba(0,0,0,.08)",
            }}>{avatar.glyph}</div>
            <input value={name} onChange={e => setName(e.target.value)}
              placeholder={lang === "ar" ? "اسمك" : "Your name"}
              style={{
                width: "100%", padding: "14px 16px", borderRadius: 16,
                border: "3px solid color-mix(in oklab, var(--ink-soft) 25%, white)",
                fontSize: 20, fontFamily: "var(--display-font)", fontWeight: 700,
                textAlign: "center", outline: "none", color: "var(--ink)",
                background: "color-mix(in oklab, var(--bg) 60%, white)",
              }} />
          </div>
          <button className="btn btn-primary btn-big" disabled={!name} onClick={() => onDone({ avatar, name })} style={{
            width: "100%", marginTop: "auto", opacity: name ? 1 : 0.4,
          }}>
            {T("letsGo")} <Icon name="rocket" size={22} color="#fff" />
          </button>
        </Stack>
      )}
    </div>
  );
};

// ========= HOME =========
const ChildHome = ({ T, lang, dir, mascot, gam, profile, onNav }) => {
  return (
    <div style={{ padding: "16px 16px 90px", background: "var(--bg)", minHeight: "100%" }}>
      {/* Greeting */}
      <Stack dir="row" align="center" justify="space-between" style={{ marginBottom: 12 }}>
        <Stack dir="row" gap={10} align="center">
          <div style={{
            width: 52, height: 52, borderRadius: "50%",
            background: profile.avatar.color,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 28, boxShadow: "0 3px 0 rgba(0,0,0,.1)",
          }}>{profile.avatar.glyph}</div>
          <div>
            <div style={{ fontSize: 13, color: "var(--ink-soft)", fontWeight: 700 }}>{T("hi")}</div>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 22, color: "var(--ink)", lineHeight: 1 }}>{profile.name}</div>
          </div>
        </Stack>
        {gam !== "light" && (
          <Stack dir="row" gap={8}>
            <Pill color="var(--red)"><Icon name="flame" size={16} color="#fff" /> 7</Pill>
            <Pill color="var(--yellow)"><Icon name="star" size={16} color="#fff" /> 124</Pill>
          </Stack>
        )}
      </Stack>

      {/* Today's mission card */}
      <div onClick={() => onNav("lesson")} style={{
        background: `linear-gradient(135deg, var(--primary) 0%, var(--pink) 100%)`,
        borderRadius: 28,
        padding: 18,
        color: "#fff",
        position: "relative",
        overflow: "hidden",
        cursor: "pointer",
        marginBottom: 18,
        boxShadow: "0 8px 0 rgba(0,0,0,.12)",
        display: "flex",
        alignItems: "center",
        gap: 10,
        minHeight: 130,
      }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 800, opacity: .85, letterSpacing: ".05em", textTransform: "uppercase" }}>{T("todaysMission")}</div>
          <div style={{ fontFamily: "var(--display-font)", fontSize: 22, lineHeight: 1.15, marginTop: 4 }}>
            {lang === "ar" ? "عُدّ التفاحات!" : "Count the apples!"}
          </div>
          <Stack dir="row" gap={6} align="center" style={{ marginTop: 10 }}>
            <Icon name="play" size={14} color="#fff" />
            <span style={{ fontWeight: 800, fontSize: 14 }}>{T("playNow")}</span>
          </Stack>
        </div>
        <div style={{ flex: "0 0 auto" }}>
          <Mascot direction={dir} size={92} mood="wow" />
        </div>
      </div>

      {/* Subjects grid */}
      <div style={{ fontFamily: "var(--display-font)", fontSize: 18, marginBottom: 10, color: "var(--ink)" }}>{T("subjects")}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        {SUBJECTS.slice(0, 6).map(s => (
          <button key={s.id} onClick={() => onNav("lesson", s)} className="anim-wiggle" style={{
            border: "none",
            background: `color-mix(in oklab, ${s.color} 18%, white)`,
            borderRadius: 22,
            padding: "16px 8px 12px",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
            cursor: "pointer",
            boxShadow: `0 4px 0 color-mix(in oklab, ${s.color} 35%, white)`,
            color: s.color,
          }}>
            <div style={{
              width: 46, height: 46, borderRadius: 14, background: s.color,
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
              fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18,
              boxShadow: "inset 0 -3px 0 rgba(0,0,0,.15)",
            }}>{s.emoji}</div>
            <span style={{ fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13, color: "var(--ink)" }}>{T(s.label)}</span>
          </button>
        ))}
      </div>

      {/* Continue learning */}
      <div style={{ fontFamily: "var(--display-font)", fontSize: 18, margin: "20px 0 10px", color: "var(--ink)" }}>{T("continueLearning")}</div>
      <Stack gap={10}>
        {[
          { sub: "math", title: lang === "ar" ? "الأرقام ١-١٠" : "Numbers 1-10", prog: 60, color: "var(--primary)" },
          { sub: "reading", title: lang === "ar" ? "حروف الأبجدية" : "ABC Letters", prog: 30, color: "var(--accent)" },
        ].map((c, i) => (
          <div key={i} onClick={() => onNav("lesson")} style={{
            background: "var(--surface)", borderRadius: 20, padding: 12, display: "flex", gap: 12, alignItems: "center",
            boxShadow: "var(--card-sh)", cursor: "pointer",
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: 16, background: c.color,
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
            }}>
              <Icon name="play" size={28} color="#fff" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 16, color: "var(--ink)" }}>{c.title}</div>
              <div style={{ marginTop: 6 }}>
                <ProgressBar value={c.prog} color={c.color} height={10} />
              </div>
            </div>
          </div>
        ))}
      </Stack>
    </div>
  );
};

// ========= COURSE BROWSER =========
const CourseBrowser = ({ T, lang, dir, onNav }) => {
  return (
    <div style={{ padding: "16px 16px 90px", background: "var(--bg)", minHeight: "100%" }}>
      <h2 style={{ fontFamily: "var(--display-font)", margin: "0 0 14px", fontSize: 24, color: "var(--ink)" }}>{T("subjects")}</h2>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
        {SUBJECTS.map(s => (
          <div key={s.id} onClick={() => onNav("lesson", s)} style={{
            background: s.color, borderRadius: 24, padding: 16, color: "#fff",
            cursor: "pointer", boxShadow: "0 6px 0 rgba(0,0,0,.12)",
            position: "relative", overflow: "hidden", aspectRatio: "1 / 1.05",
            display: "flex", flexDirection: "column", justifyContent: "space-between",
          }}>
            <div style={{
              width: 48, height: 48, borderRadius: 14,
              background: "rgba(255,255,255,.25)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 22,
            }}>{s.emoji}</div>
            <div>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 20 }}>{T(s.label)}</div>
              <div style={{ fontSize: 12, opacity: .85, fontWeight: 700, marginTop: 2 }}>
                {Math.floor(8 + Math.random() * 20)} {lang === "ar" ? "درسًا" : "lessons"}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ========= LESSON / QUIZ =========
const Lesson = ({ T, lang, dir, mascot, gam, onNav }) => {
  const [stage, setStage] = React.useState("intro"); // intro -> q1 -> q2 -> done
  const [feedback, setFeedback] = React.useState(null); // 'right' | 'wrong'
  const [stars, setStars] = React.useState(0);

  const Q1 = lang === "ar" ? "كم تفاحة؟" : "How many apples?";
  const Q1opts = [2, 3, 4];
  const Q1right = 3;

  const Q2 = lang === "ar" ? "أيّ حرف هذا؟" : "Which letter is this?";
  const Q2opts = ["A", "B", "C"];
  const Q2right = "A";

  const answer = (val, correct, nextStage) => {
    if (val === correct) {
      setFeedback("right");
      setStars(s => s + 1);
      setTimeout(() => { setFeedback(null); setStage(nextStage); }, 1100);
    } else {
      setFeedback("wrong");
      setTimeout(() => setFeedback(null), 800);
    }
  };

  return (
    <div style={{ padding: "16px 16px 24px", background: "var(--bg)", minHeight: "100%", position: "relative" }}>
      {/* header */}
      <Stack dir="row" align="center" justify="space-between" style={{ marginBottom: 14 }}>
        <button onClick={() => onNav("home")} style={{
          width: 42, height: 42, borderRadius: 14, border: "none",
          background: "var(--surface)", boxShadow: "0 3px 0 rgba(0,0,0,.08)",
          display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
        }}>
          <Icon name={dir === "rtl" ? "chevron" : "chevronL"} size={22} color="var(--ink)" />
        </button>
        <div style={{ flex: 1, padding: "0 12px" }}>
          <ProgressBar
            value={stage === "intro" ? 10 : stage === "q1" ? 40 : stage === "q2" ? 70 : 100}
            color="var(--primary)" height={14} />
        </div>
        <Pill color="var(--yellow)"><Icon name="star" size={16} color="#fff" /> {stars}</Pill>
      </Stack>

      {stage === "intro" && (
        <Stack gap={20} align="center" style={{ textAlign: "center", paddingTop: 30 }}>
          {mascot && <Mascot direction={dir} size={140} float />}
          <h2 style={{ fontFamily: "var(--display-font)", fontSize: 28, margin: 0, color: "var(--ink)" }}>
            {lang === "ar" ? "هيّا نتعلّم العدّ!" : "Let's count!"}
          </h2>
          <p style={{ color: "var(--ink-soft)", fontWeight: 700, margin: 0 }}>
            {lang === "ar" ? "٣ أنشطة قصيرة" : "3 short activities"}
          </p>
          <button className="btn btn-primary btn-big" onClick={() => setStage("q1")} style={{ width: "100%", marginTop: 16 }}>
            {T("playNow")}
          </button>
        </Stack>
      )}

      {stage === "q1" && (
        <div>
          <div style={{
            background: "var(--surface)", borderRadius: 28, padding: 22, textAlign: "center",
            boxShadow: "var(--card-sh)",
          }}>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 22, color: "var(--ink)", marginBottom: 14 }}>{Q1}</div>
            <div style={{ display: "flex", justifyContent: "center", gap: 6, fontSize: 44 }}>
              {Array.from({ length: Q1right }).map((_, i) => <span key={i}>🍎</span>)}
            </div>
          </div>
          <div style={{ marginTop: 16, fontSize: 13, color: "var(--ink-soft)", textAlign: "center", fontWeight: 700 }}>{T("tap")}</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginTop: 12 }}>
            {Q1opts.map(o => (
              <button key={o} onClick={() => answer(o, Q1right, "q2")} style={{
                background: "var(--surface)", border: "4px solid color-mix(in oklab, var(--primary) 25%, white)",
                borderRadius: 20, padding: "20px 0", fontSize: 36, fontFamily: "var(--display-font)", fontWeight: 800,
                color: "var(--ink)", cursor: "pointer", boxShadow: "0 5px 0 rgba(0,0,0,.08)",
              }}>{o}</button>
            ))}
          </div>
        </div>
      )}

      {stage === "q2" && (
        <div>
          <div style={{
            background: "var(--surface)", borderRadius: 28, padding: 22, textAlign: "center",
            boxShadow: "var(--card-sh)",
          }}>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 22, color: "var(--ink)", marginBottom: 14 }}>{Q2}</div>
            <div style={{
              fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 96,
              color: "var(--accent)", lineHeight: 1,
            }}>A</div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginTop: 16 }}>
            {Q2opts.map(o => (
              <button key={o} onClick={() => answer(o, Q2right, "done")} style={{
                background: "var(--surface)", border: "4px solid color-mix(in oklab, var(--accent) 25%, white)",
                borderRadius: 20, padding: "20px 0", fontSize: 36, fontFamily: "var(--display-font)", fontWeight: 800,
                color: "var(--ink)", cursor: "pointer", boxShadow: "0 5px 0 rgba(0,0,0,.08)",
              }}>{o}</button>
            ))}
          </div>
        </div>
      )}

      {stage === "done" && (
        <Stack gap={16} align="center" style={{ textAlign: "center", paddingTop: 20 }}>
          <div className="anim-bounce">
            <Mascot direction={dir} size={150} mood="wow" />
          </div>
          <h2 style={{ fontFamily: "var(--display-font)", fontSize: 32, margin: 0, color: "var(--green)" }}>
            {T("greatJob")}
          </h2>
          <StarRow count={stars} total={3} size={48} />
          {gam !== "light" && (
            <Stack dir="row" gap={10}>
              <Pill color="var(--yellow)" size="lg"><Icon name="star" size={20} color="#fff" /> +{stars * 10}</Pill>
              <Pill color="var(--primary)" size="lg"><Icon name="coin" size={20} color="#fff" /> +5</Pill>
            </Stack>
          )}
          <button className="btn btn-primary btn-big" onClick={() => onNav("home")} style={{ width: "100%", marginTop: 14 }}>
            {T("next")}
          </button>
        </Stack>
      )}

      {/* feedback overlay */}
      {feedback && (
        <div style={{
          position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(0,0,0,.15)", zIndex: 50, pointerEvents: "none",
        }}>
          <div className="anim-bounce" style={{
            background: feedback === "right" ? "var(--green)" : "var(--red)",
            width: 120, height: 120, borderRadius: "50%",
            display: "flex", alignItems: "center", justifyContent: "center",
            boxShadow: "0 12px 30px rgba(0,0,0,.3)",
          }}>
            <Icon name={feedback === "right" ? "check" : "x"} size={70} color="#fff" stroke={4} />
          </div>
        </div>
      )}
    </div>
  );
};

// ========= REWARDS =========
const Rewards = ({ T, lang, dir, gam }) => {
  const badges = [
    { name: lang === "ar" ? "بطل الرياضيات" : "Math hero", color: "var(--primary)", icon: "trophy", earned: true },
    { name: lang === "ar" ? "قارئ نجم" : "Star reader", color: "var(--accent)", icon: "book", earned: true },
    { name: lang === "ar" ? "عبقريّ الألوان" : "Color genius", color: "var(--pink)", icon: "palette", earned: true },
    { name: lang === "ar" ? "صائم ٧ أيام" : "7-day streak", color: "var(--red)", icon: "flame", earned: true },
    { name: lang === "ar" ? "عالِم صغير" : "Lil' scientist", color: "var(--green)", icon: "flask", earned: false },
    { name: lang === "ar" ? "مُبرمج" : "Coder", color: "var(--violet)", icon: "code", earned: false },
  ];
  return (
    <div style={{ padding: "16px 16px 90px", background: "var(--bg)", minHeight: "100%" }}>
      <h2 style={{ fontFamily: "var(--display-font)", fontSize: 24, margin: "0 0 14px", color: "var(--ink)" }}>{T("rewards")}</h2>
      {/* totals */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 18 }}>
        {[
          { label: T("streak"), val: 7, color: "var(--red)", icon: "flame" },
          { label: T("stars"), val: 124, color: "var(--yellow)", icon: "star" },
          { label: T("coins"), val: 38, color: "var(--primary)", icon: "coin" },
        ].map((s, i) => (
          <div key={i} style={{
            background: "var(--surface)", borderRadius: 20, padding: "12px 8px", textAlign: "center",
            boxShadow: "var(--card-sh)",
          }}>
            <div style={{
              width: 40, height: 40, margin: "0 auto 6px", borderRadius: 12, background: s.color,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Icon name={s.icon} size={22} color="#fff" />
            </div>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 22, color: "var(--ink)", lineHeight: 1 }}>{s.val}</div>
            <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700, marginTop: 2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ fontFamily: "var(--display-font)", fontSize: 18, marginBottom: 10, color: "var(--ink)" }}>{T("badges")}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        {badges.map((b, i) => (
          <div key={i} style={{
            background: "var(--surface)", borderRadius: 18, padding: "14px 6px", textAlign: "center",
            boxShadow: "var(--card-sh)", opacity: b.earned ? 1 : 0.4,
          }}>
            <div style={{
              width: 56, height: 56, margin: "0 auto 6px", borderRadius: "50%",
              background: b.earned ? b.color : "rgba(0,0,0,.1)",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: b.earned ? `0 4px 0 color-mix(in oklab, ${b.color} 60%, black)` : "none",
              position: "relative",
            }}>
              <Icon name={b.icon} size={28} color="#fff" />
              {!b.earned && (
                <div style={{
                  position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
                }}>
                  <Icon name="lock" size={20} color="#fff" />
                </div>
              )}
            </div>
            <div style={{ fontSize: 11, fontWeight: 800, color: "var(--ink)", lineHeight: 1.2, padding: "0 4px" }}>{b.name}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ========= PROFILE =========
const ChildProfile = ({ T, lang, dir, profile }) => (
  <div style={{ padding: "16px 16px 90px", background: "var(--bg)", minHeight: "100%" }}>
    <div style={{ textAlign: "center", padding: "20px 0" }}>
      <div style={{
        width: 110, height: 110, margin: "0 auto 12px", borderRadius: "50%",
        background: profile.avatar.color, display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 60, boxShadow: "0 6px 0 rgba(0,0,0,.1)",
      }}>{profile.avatar.glyph}</div>
      <div style={{ fontFamily: "var(--display-font)", fontSize: 26, color: "var(--ink)" }}>{profile.name}</div>
      <Stack dir="row" gap={8} justify="center" style={{ marginTop: 8 }}>
        <Pill color="var(--primary)">{lang === "ar" ? "المستوى ٣" : "Level 3"}</Pill>
        <Pill color="var(--yellow)"><Icon name="star" size={14} color="#fff" /> 124</Pill>
      </Stack>
    </div>

    <div style={{ background: "var(--surface)", borderRadius: 20, boxShadow: "var(--card-sh)", overflow: "hidden" }}>
      {[
        { icon: "speaker", label: T("sound"), toggle: true, on: true },
        { icon: "headphone", label: T("music"), toggle: true, on: false },
        { icon: "palette", label: lang === "ar" ? "السمة" : "Theme" },
        { icon: "lock", label: T("parentZone") },
        { icon: "settings", label: T("settings") },
      ].map((row, i, arr) => (
        <div key={i} style={{
          display: "flex", alignItems: "center", gap: 14,
          padding: "16px 18px",
          borderBottom: i < arr.length - 1 ? "1px solid color-mix(in oklab, var(--ink-soft) 15%, transparent)" : "none",
        }}>
          <div style={{
            width: 38, height: 38, borderRadius: 12, background: "color-mix(in oklab, var(--primary) 15%, white)",
            display: "flex", alignItems: "center", justifyContent: "center", color: "var(--primary)",
          }}><Icon name={row.icon} size={20} /></div>
          <div style={{ flex: 1, fontFamily: "var(--display-font)", fontSize: 16, color: "var(--ink)" }}>{row.label}</div>
          {row.toggle ? (
            <div style={{
              width: 50, height: 28, borderRadius: 999, background: row.on ? "var(--green)" : "rgba(0,0,0,.15)",
              position: "relative", transition: "background .2s",
            }}>
              <div style={{
                position: "absolute", top: 3, [dir === "rtl" ? "right" : "left"]: row.on ? 25 : 3,
                width: 22, height: 22, borderRadius: "50%", background: "#fff",
                transition: "all .2s", boxShadow: "0 2px 4px rgba(0,0,0,.2)",
              }} />
            </div>
          ) : (
            <Icon name={dir === "rtl" ? "chevronL" : "chevron"} size={20} color="var(--ink-soft)" />
          )}
        </div>
      ))}
    </div>
  </div>
);

// ========= BOTTOM NAV =========
const BottomNav = ({ T, current, onNav, dir }) => {
  const items = [
    { id: "home", icon: "home", label: T("home") },
    { id: "browser", icon: "grid", label: T("learn") },
    { id: "rewards", icon: "trophy", label: T("rewards") },
    { id: "profile", icon: "smile", label: T("me") },
  ];
  return (
    <div style={{
      position: "absolute", bottom: 0, left: 0, right: 0,
      background: "var(--surface)", borderTop: "1px solid rgba(0,0,0,.06)",
      padding: "8px 6px 16px",
      display: "flex", justifyContent: "space-around",
      boxShadow: "0 -8px 20px rgba(0,0,0,.06)",
    }}>
      {items.map(it => (
        <button key={it.id} onClick={() => onNav(it.id)} style={{
          background: "transparent", border: "none", cursor: "pointer",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 2,
          padding: "6px 12px", borderRadius: 14,
          color: current === it.id ? "var(--primary)" : "var(--ink-soft)",
        }}>
          <div style={{
            background: current === it.id ? "color-mix(in oklab, var(--primary) 18%, white)" : "transparent",
            borderRadius: 12, padding: "6px 12px",
          }}>
            <Icon name={it.icon} size={26} color={current === it.id ? "var(--primary)" : "var(--ink-soft)"} />
          </div>
          <span style={{ fontSize: 11, fontWeight: 800, fontFamily: "var(--display-font)" }}>{it.label}</span>
        </button>
      ))}
    </div>
  );
};

// ========= ChildApp wrapper =========
const ChildApp = ({ T, lang, dir, mascot, gam, profile, setProfile, initialScreen }) => {
  const [screen, setScreen] = React.useState(initialScreen || (profile ? "home" : "onboarding"));

  React.useEffect(() => {
    if (!profile && screen !== "onboarding") setScreen("onboarding");
  }, [profile]);

  const onNav = (s) => setScreen(s);

  return (
    <div style={{ height: "100%", position: "relative", background: "var(--bg)" }}>
      {screen === "onboarding" && (
        <Onboarding T={T} lang={lang} dir={dir} mascot={mascot} onDone={(p) => { setProfile(p); setScreen("home"); }} />
      )}
      {screen === "home" && profile && <ChildHome T={T} lang={lang} dir={dir} mascot={mascot} gam={gam} profile={profile} onNav={onNav} />}
      {screen === "browser" && <CourseBrowser T={T} lang={lang} dir={dir} onNav={onNav} />}
      {screen === "lesson" && <Lesson T={T} lang={lang} dir={dir} mascot={mascot} gam={gam} onNav={onNav} />}
      {screen === "rewards" && <Rewards T={T} lang={lang} dir={dir} gam={gam} />}
      {screen === "profile" && profile && <ChildProfile T={T} lang={lang} dir={dir} profile={profile} />}
      {screen !== "onboarding" && screen !== "lesson" && (
        <BottomNav T={T} current={screen} onNav={onNav} dir={dir} />
      )}
    </div>
  );
};

Object.assign(window, {
  ChildApp, Onboarding, ChildHome, CourseBrowser, Lesson, Rewards, ChildProfile, BottomNav,
  SUBJECTS, AVATARS,
});
