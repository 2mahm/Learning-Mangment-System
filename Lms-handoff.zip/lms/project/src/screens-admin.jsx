// ADMIN — multi-page school admin dashboard

const ADMIN_CLASSES = [
  { n: "Happy Class 2A", n_ar: "روضة المرح ٢", t: "Mrs. Sara",   s: 24, p: 86, c: "var(--primary)" },
  { n: "ABC Stars",      n_ar: "نجوم الأبجدية", t: "Mr. Hassan", s: 22, p: 74, c: "var(--accent)" },
  { n: "Numbers Class",  n_ar: "صفّ الأرقام",   t: "Mrs. Layla", s: 20, p: 91, c: "var(--green)" },
  { n: "Qur'an Class",   n_ar: "صفّ القرآن",    t: "Sh. Yusuf",  s: 18, p: 65, c: "var(--violet)" },
  { n: "Little Artists", n_ar: "فنّانون صغار",  t: "Ms. Hala",   s: 16, p: 79, c: "var(--red)" },
  { n: "Tiny Coders",    n_ar: "مبرمجون صغار", t: "Mr. Khalid", s: 14, p: 72, c: "var(--pink)" },
];

const ADMIN_TEACHERS = [
  { name: "Mrs. Sara Hassan",   classes: 2, students: 46, rating: 4.8, color: "#FF8A3D", glyph: "S" },
  { name: "Mr. Hassan Khalil",  classes: 1, students: 22, rating: 4.6, color: "#4CC9F0", glyph: "H" },
  { name: "Mrs. Layla Mahmoud", classes: 2, students: 40, rating: 4.9, color: "#FF6B9D", glyph: "L" },
  { name: "Sh. Yusuf Ahmed",    classes: 1, students: 18, rating: 4.7, color: "#8B5CF6", glyph: "Y" },
  { name: "Ms. Hala Naser",     classes: 1, students: 16, rating: 4.5, color: "#FFD23F", glyph: "H" },
  { name: "Mr. Khalid Omar",    classes: 1, students: 14, rating: 4.6, color: "#4CD471", glyph: "K" },
];

const AdminSidebar = ({ T, lang, dir, page, setPage }) => {
  const items = [
    { id: "overview", label: T("schoolAdmin"),  icon: "home" },
    { id: "teachers", label: T("teachers"),     icon: "users" },
    { id: "classes",  label: T("classes"),      icon: "grid" },
    { id: "content",  label: T("content"),      icon: "book" },
    { id: "reports",  label: lang === "ar" ? "التقارير" : "Reports", icon: "chart" },
    { id: "settings", label: T("settings"),     icon: "settings" },
  ];
  return (
    <aside style={{
      width: 220, background: "var(--surface)", borderInlineEnd: "1px solid rgba(0,0,0,.06)",
      padding: "20px 14px", display: "flex", flexDirection: "column", gap: 4,
    }}>
      <Stack dir="row" gap={8} align="center" style={{ marginBottom: 18, padding: "0 4px" }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: "linear-gradient(135deg, var(--primary), var(--pink))",
          display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
          fontFamily: "var(--display-font)", fontWeight: 800,
        }}>K</div>
        <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18 }}>Kiddo</div>
      </Stack>
      {items.map((i) => (
        <button key={i.id} onClick={() => setPage(i.id)} style={{
          display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", border: "none",
          background: page === i.id ? "color-mix(in oklab, var(--primary) 12%, white)" : "transparent",
          color: page === i.id ? "var(--primary)" : "var(--ink-soft)",
          borderRadius: 12, cursor: "pointer", fontFamily: "var(--body-font)", fontSize: 14, fontWeight: 700,
          textAlign: dir === "rtl" ? "right" : "left",
        }}>
          <Icon name={i.icon} size={20} />
          <span>{i.label}</span>
        </button>
      ))}
    </aside>
  );
};

const AdminOverview = ({ T, lang, dir }) => (
  <div>
    <PageHeader
      title={lang === "ar" ? "مدرسة الفجر الدولية" : "Al-Fajr Intl. School"}
      sub={lang === "ar" ? "نظرة عامّة" : "Overview"}
      actions={<>
        <button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}>{lang === "ar" ? "تصدير" : "Export"}</button>
        <button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}><Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "دعوة" : "Invite"}</button>
      </>}
    />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 18 }}>
      {[
        { l: T("students"), v: 412, sub: "+18 " + (lang === "ar" ? "هذا الشهر" : "this month"), c: "var(--primary)", i: "users" },
        { l: T("teachers"), v: 28, sub: lang === "ar" ? "نشطون" : "active", c: "var(--accent)", i: "user" },
        { l: T("classes"), v: 18, sub: lang === "ar" ? "صفًّا" : "running", c: "var(--green)", i: "grid" },
        { l: lang === "ar" ? "الإنجاز" : "Completion", v: "82%", sub: "+6%", c: "var(--violet)", i: "chart" },
      ].map((s, i) => (
        <div key={i} className="card" style={{ padding: 16 }}>
          <Stack dir="row" align="center" gap={12}>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: `color-mix(in oklab, ${s.c} 18%, white)`, color: s.c,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}><Icon name={s.i} size={20} /></div>
            <div>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 22, fontWeight: 800, lineHeight: 1 }}>{s.v}</div>
              <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700, marginTop: 2 }}>{s.l} · {s.sub}</div>
            </div>
          </Stack>
        </div>
      ))}
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 14 }}>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{T("classes")}</h3>
        <Stack gap={8}>
          {ADMIN_CLASSES.slice(0, 4).map((c, i) => (
            <Stack key={i} dir="row" align="center" gap={10} style={{ padding: "8px 10px", background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 12 }}>
              <div style={{ width: 36, height: 36, borderRadius: 10, background: c.c, color: "#fff",
                display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--display-font)", fontWeight: 800 }}>{(lang === "ar" ? c.n_ar : c.n).charAt(0)}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{lang === "ar" ? c.n_ar : c.n}</div>
                <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{c.t} · {c.s} {T("students")}</div>
              </div>
              <div style={{ width: 80 }}><ProgressBar value={c.p} color={c.c} height={6} /></div>
              <span className="mono" style={{ fontWeight: 800, fontSize: 12, minWidth: 32 }}>{c.p}%</span>
            </Stack>
          ))}
        </Stack>
      </div>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{T("content")}</h3>
        <Stack gap={8}>
          {SUBJECTS.slice(0, 6).map((s) => (
            <Stack key={s.id} dir="row" align="center" gap={10}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: s.color, color: "#fff",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 13 }}>{s.emoji}</div>
              <div style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{T(s.label)}</div>
              <span style={{ color: "var(--ink-soft)", fontWeight: 700, fontSize: 12 }}>{Math.floor(8 + ((s.id.length * 7) % 22))} {lang === "ar" ? "درس" : "lessons"}</span>
            </Stack>
          ))}
        </Stack>
      </div>
    </div>
  </div>
);

const AdminTeachers = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("teachers")} sub={`${ADMIN_TEACHERS.length} ${lang === "ar" ? "معلّمًا نشطًا" : "active teachers"}`}
      actions={<button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}><Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "دعوة معلّم" : "Invite teacher"}</button>} />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }}>
      {ADMIN_TEACHERS.map((t, i) => (
        <div key={i} className="card" style={{ padding: 18 }}>
          <Stack dir="row" gap={12} align="center" style={{ marginBottom: 12 }}>
            <div style={{
              width: 52, height: 52, borderRadius: "50%", background: t.color, color: "#fff",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 22,
            }}>{t.glyph}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 15, fontWeight: 800 }}>{t.name}</div>
              <Stack dir="row" gap={4} align="center">
                <Icon name="star" size={14} color="var(--yellow)" />
                <span style={{ fontWeight: 800, fontSize: 12 }}>{t.rating}</span>
              </Stack>
            </div>
          </Stack>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div style={{ background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 10, padding: 10, textAlign: "center" }}>
              <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18 }}>{t.classes}</div>
              <div style={{ fontSize: 10, color: "var(--ink-soft)", fontWeight: 700 }}>{T("classes")}</div>
            </div>
            <div style={{ background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 10, padding: 10, textAlign: "center" }}>
              <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18 }}>{t.students}</div>
              <div style={{ fontSize: 10, color: "var(--ink-soft)", fontWeight: 700 }}>{T("students")}</div>
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const AdminClasses = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("classes")} sub={`${ADMIN_CLASSES.length} ${lang === "ar" ? "صفّ" : "classes running"}`}
      actions={<button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}><Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "صفّ جديد" : "New class"}</button>} />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 }}>
      {ADMIN_CLASSES.map((c, i) => (
        <div key={i} className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{
            background: c.c, padding: "16px 18px", color: "#fff",
            display: "flex", alignItems: "center", gap: 12,
          }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: "rgba(255,255,255,.25)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 20 }}>{(lang === "ar" ? c.n_ar : c.n).charAt(0)}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 16 }}>{lang === "ar" ? c.n_ar : c.n}</div>
              <div style={{ fontSize: 12, opacity: .9, fontWeight: 700 }}>{c.t}</div>
            </div>
            <Pill color="rgba(255,255,255,.25)" style={{ color: "#fff" }}>{c.s} {T("students")}</Pill>
          </div>
          <div style={{ padding: 16 }}>
            <Stack dir="row" justify="space-between" style={{ marginBottom: 6 }}>
              <span style={{ fontWeight: 700, fontSize: 12, color: "var(--ink-soft)" }}>{lang === "ar" ? "متوسط الإنجاز" : "Avg completion"}</span>
              <span className="mono" style={{ fontWeight: 800, fontSize: 13 }}>{c.p}%</span>
            </Stack>
            <ProgressBar value={c.p} color={c.c} height={8} />
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6, marginTop: 12 }}>
              {[
                { l: lang === "ar" ? "دروس" : "Lessons", v: 24 },
                { l: lang === "ar" ? "نشاط" : "Active", v: c.s - 2 },
                { l: lang === "ar" ? "معدّل" : "Avg", v: c.p + "%" },
              ].map((m, j) => (
                <div key={j} style={{ background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 10, padding: "8px 6px", textAlign: "center" }}>
                  <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 14 }}>{m.v}</div>
                  <div style={{ fontSize: 10, color: "var(--ink-soft)", fontWeight: 700 }}>{m.l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
      <div className="card" style={{
        padding: 22, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10,
        border: "2px dashed color-mix(in oklab, var(--ink-soft) 30%, white)", boxShadow: "none", background: "transparent",
        color: "var(--ink-soft)", cursor: "pointer", minHeight: 220,
      }}>
        <div style={{ width: 56, height: 56, borderRadius: "50%", background: "color-mix(in oklab, var(--primary) 15%, white)",
          color: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="plus" size={28} /></div>
        <div style={{ fontFamily: "var(--display-font)", fontWeight: 700 }}>{lang === "ar" ? "أنشئ صفًّا جديدًا" : "Create new class"}</div>
      </div>
    </div>
  </div>
);

const AdminContent = ({ T, lang, dir }) => {
  const [filter, setFilter] = React.useState("all");
  const lessons = [
    { t: lang === "ar" ? "العدّ من ١ إلى ١٠" : "Counting 1–10", sub: "math",    plays: 1240, time: 8, status: "live" },
    { t: lang === "ar" ? "الحروف A-F" : "Letters A–F",          sub: "reading", plays: 980,  time: 6, status: "live" },
    { t: lang === "ar" ? "ألوان قوس قزح" : "Rainbow colors",    sub: "art",     plays: 720,  time: 10, status: "live" },
    { t: lang === "ar" ? "أصوات الحيوانات" : "Animal sounds",   sub: "science", plays: 640,  time: 7, status: "live" },
    { t: lang === "ar" ? "الجمع البسيط" : "Simple addition",    sub: "math",    plays: 1100, time: 9, status: "live" },
    { t: lang === "ar" ? "أحرف عربية ا-د" : "Arabic أ-د",       sub: "arabic",  plays: 530,  time: 8, status: "draft" },
    { t: lang === "ar" ? "سورة الفاتحة" : "Surat Al-Fatiha",    sub: "quran",   plays: 410,  time: 12, status: "live" },
    { t: lang === "ar" ? "حلقة برمجة ١" : "Code loop 1",        sub: "coding",  plays: 220,  time: 10, status: "draft" },
  ];
  const filtered = lessons.filter(l => filter === "all" || l.sub === filter);
  return (
    <div>
      <PageHeader title={T("content")} sub={`${lessons.length} ${lang === "ar" ? "درسًا في المكتبة" : "lessons in library"}`}
        actions={<>
          <button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}><Icon name="search" size={16} /> {lang === "ar" ? "بحث" : "Search"}</button>
          <button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}><Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "إضافة درس" : "New lesson"}</button>
        </>} />
      {/* Subject filter chips */}
      <Stack dir="row" gap={6} style={{ marginBottom: 14, flexWrap: "wrap" }}>
        <button onClick={() => setFilter("all")} style={{
          padding: "8px 14px", borderRadius: 999, border: "none", cursor: "pointer",
          background: filter === "all" ? "var(--ink)" : "var(--surface)",
          color: filter === "all" ? "var(--bg)" : "var(--ink-soft)",
          fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13,
        }}>{lang === "ar" ? "الكلّ" : "All"} · {lessons.length}</button>
        {SUBJECTS.slice(0, 8).map(s => (
          <button key={s.id} onClick={() => setFilter(s.id)} style={{
            padding: "8px 14px", borderRadius: 999, border: "none", cursor: "pointer",
            background: filter === s.id ? s.color : "var(--surface)",
            color: filter === s.id ? "#fff" : "var(--ink-soft)",
            fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13,
          }}>{T(s.label)}</button>
        ))}
      </Stack>
      {/* Subject summary */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 14 }}>
        {SUBJECTS.slice(0, 4).map(s => {
          const count = lessons.filter(l => l.sub === s.id).length;
          return (
            <div key={s.id} className="card" style={{ padding: 14, display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: s.color, color: "#fff",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 15 }}>{s.emoji}</div>
              <div>
                <div style={{ fontFamily: "var(--display-font)", fontSize: 18, fontWeight: 800, lineHeight: 1 }}>{count}</div>
                <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{T(s.label)}</div>
              </div>
            </div>
          );
        })}
      </div>
      {/* Lessons grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
        {filtered.map((l, i) => {
          const sub = SUBJECTS.find(s => s.id === l.sub);
          return (
            <div key={i} className="card" style={{ padding: 0, overflow: "hidden", cursor: "pointer" }}>
              <div style={{ height: 90, background: `linear-gradient(135deg, ${sub.color}, color-mix(in oklab, ${sub.color} 60%, var(--pink)))`,
                position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, color: "rgba(255,255,255,.95)", fontSize: 36 }}>{sub.emoji}</div>
                <div style={{ position: "absolute", top: 8, insetInlineEnd: 8 }}>
                  {l.status === "live"
                    ? <Tag color="var(--green)" style={{ background: "var(--green)", color: "#fff" }}>● {lang === "ar" ? "منشور" : "Live"}</Tag>
                    : <Tag color="var(--ink-soft)" style={{ background: "rgba(255,255,255,.3)", color: "#fff" }}>{lang === "ar" ? "مسودة" : "Draft"}</Tag>}
                </div>
              </div>
              <div style={{ padding: 12 }}>
                <div style={{ fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 14, marginBottom: 6 }}>{l.t}</div>
                <Stack dir="row" justify="space-between" align="center">
                  <Stack dir="row" gap={8} align="center">
                    <Tag color={sub.color}>{T(sub.label)}</Tag>
                    <span style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}><Icon name="clock" size={12} /> {l.time}m</span>
                  </Stack>
                  <span style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{l.plays.toLocaleString()} {lang === "ar" ? "تشغيل" : "plays"}</span>
                </Stack>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const AdminReports = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={lang === "ar" ? "التقارير" : "Reports"} sub={lang === "ar" ? "أداء المدرسة" : "School-wide performance"}
      actions={<button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}>{lang === "ar" ? "تصدير" : "Export"}</button>} />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 14 }}>
      {[
        { l: lang === "ar" ? "إجمالي الدروس" : "Total lessons", v: "3.2k", t: "+12%", c: "var(--primary)" },
        { l: lang === "ar" ? "وقت التعلّم" : "Learning hours", v: "428h", t: "+8%", c: "var(--accent)" },
        { l: lang === "ar" ? "متوسط النتيجة" : "Avg score", v: "82%", t: "+4%", c: "var(--green)" },
        { l: lang === "ar" ? "النشاط اليومي" : "Daily active", v: "342", t: "+18", c: "var(--violet)" },
      ].map((s, i) => (
        <div key={i} className="card" style={{ padding: 16 }}>
          <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 800, textTransform: "uppercase", letterSpacing: ".05em" }}>{s.l}</div>
          <div style={{ fontFamily: "var(--display-font)", fontSize: 28, fontWeight: 800, marginTop: 4 }}>{s.v}</div>
          <div style={{ fontSize: 12, color: s.c, fontWeight: 800, marginTop: 2 }}>{s.t}</div>
        </div>
      ))}
    </div>
    <div className="card" style={{ padding: 20, marginBottom: 14 }}>
      <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 14px", fontSize: 16 }}>{lang === "ar" ? "النشاط الأسبوعي" : "Weekly engagement"}</h3>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 12, height: 180 }}>
        {[180, 220, 240, 210, 280, 320, 260, 290, 340, 360, 330, 380].map((v, i) => (
          <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <div style={{ width: "100%", height: `${(v / 400) * 150}px`,
              background: i === 11 ? "var(--primary)" : `color-mix(in oklab, var(--primary) 35%, white)`,
              borderRadius: 6 }} />
            <div style={{ fontSize: 10, color: "var(--ink-soft)", fontWeight: 700 }}>W{i+1}</div>
          </div>
        ))}
      </div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "أعلى الصفوف" : "Top classes"}</h3>
        <Stack gap={6}>
          {[...ADMIN_CLASSES].sort((a,b) => b.p - a.p).slice(0, 4).map((c, i) => (
            <Stack key={i} dir="row" gap={10} align="center" style={{ padding: "8px 10px", borderRadius: 10, background: "color-mix(in oklab, var(--bg) 60%, white)" }}>
              <span style={{ fontFamily: "var(--display-font)", fontWeight: 800, color: "var(--ink-soft)", width: 18 }}>{i+1}</span>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: c.c, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 12 }}>{(lang === "ar" ? c.n_ar : c.n).charAt(0)}</div>
              <span style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{lang === "ar" ? c.n_ar : c.n}</span>
              <Pill color="var(--green)" size="sm">{c.p}%</Pill>
            </Stack>
          ))}
        </Stack>
      </div>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "حسب المادّة" : "By subject"}</h3>
        <Stack gap={10}>
          {[
            { sub: "math", v: 84, color: "var(--primary)" },
            { sub: "reading", v: 76, color: "var(--accent)" },
            { sub: "science", v: 70, color: "var(--green)" },
            { sub: "art", v: 88, color: "var(--red)" },
            { sub: "quran", v: 79, color: "var(--violet)" },
          ].map((r, i) => (
            <div key={i}>
              <Stack dir="row" justify="space-between"><span style={{ fontWeight: 700, fontSize: 12 }}>{T(r.sub)}</span><span className="mono" style={{ fontWeight: 800, fontSize: 12 }}>{r.v}%</span></Stack>
              <ProgressBar value={r.v} color={r.color} height={8} />
            </div>
          ))}
        </Stack>
      </div>
    </div>
  </div>
);

const AdminSettings = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("settings")} sub={lang === "ar" ? "إعدادات المدرسة" : "School settings"} />
    <div className="card" style={{ padding: 0, overflow: "hidden", maxWidth: 700 }}>
      {[
        { i: "user",     l: lang === "ar" ? "معلومات المدرسة" : "School info", v: "Al-Fajr Intl." },
        { i: "users",    l: lang === "ar" ? "الأذونات" : "Permissions", v: lang === "ar" ? "٤ أدوار" : "4 roles" },
        { i: "bell",     l: lang === "ar" ? "الإشعارات" : "Notifications", v: lang === "ar" ? "مفعّلة" : "On" },
        { i: "lock",     l: lang === "ar" ? "الأمان" : "Security", v: "2FA" },
        { i: "palette",  l: lang === "ar" ? "السمة" : "Theme", v: lang === "ar" ? "فاتح" : "Light" },
        { i: "speaker",  l: lang === "ar" ? "اللغة" : "Language", v: lang === "ar" ? "العربية" : "English" },
        { i: "coin",     l: lang === "ar" ? "الفوترة" : "Billing", v: "School Plan" },
      ].map((row, i, arr) => (
        <div key={i} style={{
          display: "flex", alignItems: "center", gap: 14, padding: "14px 18px",
          borderBottom: i < arr.length - 1 ? "1px solid rgba(0,0,0,.05)" : "none", cursor: "pointer",
        }}>
          <div style={{
            width: 34, height: 34, borderRadius: 10, background: "color-mix(in oklab, var(--primary) 15%, white)",
            color: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center",
          }}><Icon name={row.i} size={18} /></div>
          <div style={{ flex: 1, fontWeight: 700, fontSize: 14 }}>{row.l}</div>
          <div style={{ color: "var(--ink-soft)", fontWeight: 700, fontSize: 13 }}>{row.v}</div>
          <Icon name={dir === "rtl" ? "chevronL" : "chevron"} size={18} color="var(--ink-soft)" />
        </div>
      ))}
    </div>
  </div>
);

const AdminDashboard = ({ T, lang, dir }) => {
  const [page, setPage] = React.useState("overview");
  return (
    <div style={{ display: "flex", height: "100%", background: "var(--bg)", color: "var(--ink)" }}>
      <AdminSidebar T={T} lang={lang} dir={dir} page={page} setPage={setPage} />
      <main style={{ flex: 1, padding: 22, overflow: "auto" }}>
        {page === "overview" && <AdminOverview T={T} lang={lang} dir={dir} />}
        {page === "teachers" && <AdminTeachers T={T} lang={lang} dir={dir} />}
        {page === "classes"  && <AdminClasses T={T} lang={lang} dir={dir} />}
        {page === "content"  && <AdminContent T={T} lang={lang} dir={dir} />}
        {page === "reports"  && <AdminReports T={T} lang={lang} dir={dir} />}
        {page === "settings" && <AdminSettings T={T} lang={lang} dir={dir} />}
      </main>
    </div>
  );
};

window.AdminDashboard = AdminDashboard;
