// Tweaks panel — toggleable via host

const PALETTES = {
  default:   { primary: "#FF8A3D", primaryD: "#F06A1E", accent: "#4CC9F0" },
  berry:     { primary: "#E63A8B", primaryD: "#B8126C", accent: "#8B5CF6" },
  forest:    { primary: "#22C55E", primaryD: "#15803D", accent: "#F59E0B" },
  ocean:     { primary: "#0EA5E9", primaryD: "#0369A1", accent: "#22D3A3" },
};

const TweaksPanel = ({ tweaks, setTweaks, open }) => {
  const set = (k, v) => {
    const next = { ...tweaks, [k]: v };
    setTweaks(next);
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [k]: v } }, "*");
  };

  return (
    <div className="tweaks" data-open={open ? "true" : "false"}>
      <h4>Direction</h4>
      <div className="row">
        <label>Style</label>
        <div className="seg">
          <button data-on={tweaks.direction === "A"} onClick={() => set("direction", "A")}>A · Crayon</button>
          <button data-on={tweaks.direction === "B"} onClick={() => set("direction", "B")}>B · Cloud</button>
        </div>
      </div>

      <h4 style={{ marginTop: 14 }}>Age mode</h4>
      <div className="row">
        <label>Audience</label>
        <div className="seg">
          {["early", "kid", "tween", "teen"].map(a => (
            <button key={a} data-on={tweaks.ageMode === a} onClick={() => set("ageMode", a)}>{a}</button>
          ))}
        </div>
      </div>

      <h4 style={{ marginTop: 14 }}>Palette</h4>
      <div className="row">
        <label>Theme color</label>
        <div className="swatches">
          {Object.entries(PALETTES).map(([k, p]) => (
            <button key={k} className="swatch"
              style={{ background: p.primary }}
              data-on={tweaks.palette === k}
              onClick={() => set("palette", k)} />
          ))}
        </div>
      </div>

      <h4 style={{ marginTop: 14 }}>Toggles</h4>
      <div className="row">
        <label>Mascot</label>
        <button className="toggle" data-on={tweaks.mascot} onClick={() => set("mascot", !tweaks.mascot)} />
      </div>
      <div className="row">
        <label>Dark mode</label>
        <button className="toggle"
          data-on={tweaks.theme === "dark"}
          onClick={() => set("theme", tweaks.theme === "dark" ? "light" : "dark")} />
      </div>
      <div className="row">
        <label>Language</label>
        <div className="seg">
          <button data-on={tweaks.language === "en"} onClick={() => set("language", "en")}>EN</button>
          <button data-on={tweaks.language === "ar"} onClick={() => set("language", "ar")}>AR</button>
        </div>
      </div>
      <div className="row">
        <label>Gamification</label>
        <div className="seg">
          {["light", "medium", "heavy"].map(g => (
            <button key={g} data-on={tweaks.gamification === g} onClick={() => set("gamification", g)}>{g}</button>
          ))}
        </div>
      </div>
    </div>
  );
};

window.TweaksPanel = TweaksPanel;
window.PALETTES = PALETTES;
