// KIDS DESKTOP DASHBOARD — full screen layout for tablets/desktops

const KidsDashboard = ({ T, lang, dir, tweaks, profile }) => {
  const streak = 7;
  const stars = 124;
  const coins = 38;
  const todayProgress = 60;

  return (
    <div style={{ display: "flex", height: "100%", background: "var(--bg)", color: "var(--ink)" }}>
      {/* Left rail */}
      <aside style={{
        width: 200, background: "var(--surface)", padding: "22px 14px",
        borderInlineEnd: "1px solid rgba(0,0,0,.06)",
        display: "flex", flexDirection: "column", gap: 6,
      }}>
        <Stack dir="row" gap={10} align="center" style={{ marginBottom: 16 }}>
          <div style={{
            width: 40, height: 40, borderRadius: "50%", background: profile.avatar.color,
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22,
            boxShadow: "0 3px 0 rgba(0,0,0,.1)",
          }}>{profile.avatar.glyph}</div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{T("hi")}</div>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 15, lineHeight: 1 }}>{profile.name}</div>
          </div>
        </Stack>
        {[
          { l: lang === "ar" ? "الرئيسية" : "Home",      i: "home",   active: true },
          { l: T("subjects"),                               i: "book" },
          { l: lang === "ar" ? "ألعاب" : "Games",         i: "rocket" },
          { l: T("rewards"),                                i: "trophy" },
          { l: lang === "ar" ? "الملف" : "Profile",       i: "user" },
        ].map((it, i) => (
          <button key={i} style={{
            display: "flex", alignItems: "center", gap: 10, padding: "12px 12px", border: "none",
            background: it.active ? "color-mix(in oklab, var(--primary) 15%, white)" : "transparent",
            color: it.active ? "var(--primary)" : "var(--ink-soft)",
            borderRadius: 14, cursor: "pointer", fontFamily: "var(--display-font)", fontSize: 14, fontWeight: 700,
            textAlign: dir === "rtl" ? "right" : "left",
          }}>
            <Icon name={it.i} size={20} />
            <span>{it.l}</span>
          </button>
        ))}
        <div style={{ marginTop: "auto" }}>
          <div style={{
            background: "linear-gradient(135deg, var(--yellow), var(--red))", color: "#fff",
            borderRadius: 16, padding: 12, textAlign: "center",
          }}>
            <div style={{ fontSize: 32 }}>🏆</div>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 14, marginTop: 2 }}>{lang === "ar" ? "بطل الأسبوع!" : "Star of week!"}</div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, padding: 22, overflow: "auto" }}>
        {/* Hero */}
        <div style={{
          background: `linear-gradient(135deg, var(--primary), var(--pink))`, borderRadius: 24,
          padding: 22, color: "#fff", display: "flex", alignItems: "center", gap: 16,
          boxShadow: "0 8px 0 rgba(0,0,0,.12)", marginBottom: 18,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, opacity: .9, fontWeight: 800, textTransform: "uppercase", letterSpacing: ".05em" }}>{T("todaysMission")}</div>
            <div style={{ fontFamily: "var(--display-font)", fontSize: 32, margin: "6px 0 12px", lineHeight: 1.1 }}>
              {lang === "ar" ? "عُدّ التفاحات!" : "Count the apples!"}
            </div>
            <Stack dir="row" gap={10} align="center" style={{ marginBottom: 12 }}>
              <div style={{ flex: 1, maxWidth: 260, background: "rgba(255,255,255,.25)", borderRadius: 999, height: 10, overflow: "hidden" }}>
                <div style={{ width: `${todayProgress}%`, height: "100%", background: "#fff", borderRadius: 999 }} />
              </div>
              <span style={{ fontWeight: 800, fontSize: 13 }}>{todayProgress}%</span>
            </Stack>
            <button className="btn btn-primary btn-big" style={{ background: "#fff", color: "var(--primary)", padding: "12px 22px", fontSize: 16 }}>
              <Icon name="play" size={20} /> {T("playNow")}
            </button>
          </div>
          <div style={{ flex: "0 0 auto" }}>
            {tweaks.mascot && <Mascot direction={dir} size={130} mood="wow" />}
          </div>
        </div>

        {/* Stat row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 18 }}>
          {[
            { v: streak, l: T("streak"), c: "var(--red)", i: "flame" },
            { v: stars,  l: T("stars"),  c: "var(--yellow)", i: "star" },
            { v: coins,  l: T("coins"),  c: "var(--primary)", i: "coin" },
          ].map((s, i) => (
            <div key={i} className="card" style={{ padding: 14, display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{
                width: 48, height: 48, borderRadius: 16, background: s.c,
                display: "flex", alignItems: "center", justifyContent: "center",
                boxShadow: `0 4px 0 color-mix(in oklab, ${s.c} 60%, black)`,
              }}><Icon name={s.i} size={22} color="#fff" /></div>
              <div>
                <div style={{ fontFamily: "var(--display-font)", fontSize: 28, fontWeight: 800, lineHeight: 1 }}>{s.v}</div>
                <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{s.l}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Subjects grid + Continue */}
        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
          <div>
            <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 18 }}>{T("subjects")}</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {SUBJECTS.slice(0, 6).map(s => (
                <button key={s.id} className="anim-wiggle" style={{
                  border: "none", background: s.color, borderRadius: 22, padding: "18px 10px",
                  color: "#fff", cursor: "pointer", boxShadow: "0 6px 0 rgba(0,0,0,.14)",
                  display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
                }}>
                  <div style={{
                    width: 50, height: 50, borderRadius: 15, background: "rgba(255,255,255,.25)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 20,
                  }}>{s.emoji}</div>
                  <div style={{ fontFamily: "var(--display-font)", fontSize: 14, fontWeight: 800 }}>{T(s.label)}</div>
                  <div style={{ fontSize: 10, opacity: .85, fontWeight: 700 }}>
                    {Math.floor(8 + ((s.id.length * 7) % 18))} {lang === "ar" ? "درس" : "lessons"}
                  </div>
                </button>
              ))}
            </div>
          </div>
          <div>
            <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 18 }}>{T("continueLearning")}</h3>
            <Stack gap={10}>
              {[
                { sub: "math",    title: lang === "ar" ? "الأرقام ١-١٠" : "Numbers 1-10", prog: 60, color: "var(--primary)" },
                { sub: "reading", title: lang === "ar" ? "حروف الأبجدية" : "ABC Letters",  prog: 30, color: "var(--accent)" },
                { sub: "art",     title: lang === "ar" ? "ألوان قوس قزح" : "Rainbow colors", prog: 80, color: "var(--red)" },
              ].map((c, i) => (
                <div key={i} className="card" style={{ padding: 12, display: "flex", gap: 12, alignItems: "center", cursor: "pointer" }}>
                  <div style={{
                    width: 48, height: 48, borderRadius: 14, background: c.color,
                    display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
                  }}><Icon name="play" size={24} color="#fff" /></div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: "var(--display-font)", fontSize: 14, lineHeight: 1.2 }}>{c.title}</div>
                    <div style={{ marginTop: 6 }}><ProgressBar value={c.prog} color={c.color} height={8} /></div>
                  </div>
                </div>
              ))}
            </Stack>

            <h3 style={{ fontFamily: "var(--display-font)", margin: "18px 0 10px", fontSize: 18 }}>{lang === "ar" ? "شاراتي" : "My badges"}</h3>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
              {[
                { c: "var(--primary)", i: "trophy" },
                { c: "var(--accent)",  i: "book" },
                { c: "var(--pink)",    i: "palette" },
                { c: "var(--red)",     i: "flame" },
              ].map((b, i) => (
                <div key={i} style={{
                  aspectRatio: 1, borderRadius: "50%", background: b.c, color: "#fff",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  boxShadow: `0 4px 0 color-mix(in oklab, ${b.c} 60%, black)`,
                }}><Icon name={b.i} size={22} color="#fff" /></div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

window.KidsDashboard = KidsDashboard;
