// PARENT — multi-page dashboard with sidebar nav

const PARENT_KIDS = [
  { name: "Yasmine", age: 4, color: "#FF8A3D", glyph: "🦊", today: 22, week: [10, 18, 22, 15, 25, 30, 22], streak: 7, score: 86, top: "math" },
  { name: "Omar",    age: 6, color: "#4CC9F0", glyph: "🐼", today: 14, week: [8, 12, 5, 18, 14, 20, 14],  streak: 3, score: 74, top: "reading" },
];

const ParentSidebar = ({ T, dir, page, setPage }) => {
  const items = [
    { id: "overview", label: T("parentDashboard"), icon: "home" },
    { id: "kids",     label: T("kids"),             icon: "users" },
    { id: "progress", label: T("weeklyProgress"),   icon: "chart" },
    { id: "rewards",  label: T("rewards"),          icon: "trophy" },
    { id: "limits",   label: T("setLimit"),         icon: "clock" },
    { id: "settings", label: T("settings"),         icon: "settings" },
  ];
  return (
    <aside style={{
      width: 220, background: "var(--surface)", borderInlineEnd: "1px solid rgba(0,0,0,.06)",
      padding: "20px 14px", display: "flex", flexDirection: "column", gap: 4,
    }}>
      <Stack dir="row" gap={8} align="center" style={{ marginBottom: 18, padding: "0 4px" }}>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: "linear-gradient(135deg, var(--primary), var(--pink))",
          display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
          fontFamily: "var(--display-font)", fontWeight: 800,
        }}>K</div>
        <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 18 }}>Kiddo</div>
      </Stack>
      {items.map((i) => (
        <button key={i.id} onClick={() => setPage(i.id)} style={{
          display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", border: "none",
          background: page === i.id ? "color-mix(in oklab, var(--primary) 12%, white)" : "transparent",
          color: page === i.id ? "var(--primary)" : "var(--ink-soft)",
          borderRadius: 12, cursor: "pointer", fontFamily: "var(--body-font)", fontSize: 14, fontWeight: 700,
          textAlign: dir === "rtl" ? "right" : "left",
        }}>
          <Icon name={i.icon} size={20} />
          <span>{i.label}</span>
        </button>
      ))}
    </aside>
  );
};

const PageHeader = ({ title, sub, actions }) => (
  <Stack dir="row" justify="space-between" align="center" gap={16} style={{ marginBottom: 18 }}>
    <div style={{ minWidth: 0 }}>
      <h1 style={{ fontFamily: "var(--display-font)", margin: 0, fontSize: 22, lineHeight: 1.2 }}>{title}</h1>
      {sub && <div style={{ color: "var(--ink-soft)", fontSize: 13, marginTop: 6, fontWeight: 600 }}>{sub}</div>}
    </div>
    {actions && <Stack dir="row" gap={10}>{actions}</Stack>}
  </Stack>
);

// ---------- Pages ----------
const ParentOverview = ({ T, lang, dir }) => {
  const [active, setActive] = React.useState(0);
  const k = PARENT_KIDS[active];
  return (
    <div>
      <PageHeader
        title={T("parentDashboard")}
        sub={lang === "ar" ? "نظرة على هذا الأسبوع" : "An overview of this week"}
        actions={<>
          <button className="btn btn-ghost" style={{ padding: "10px 14px", fontSize: 13 }}>
            <Icon name="bell" size={16} /> 2
          </button>
          <button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}>
            <Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "إضافة طفل" : "Add child"}
          </button>
        </>}
      />
      <Stack dir="row" gap={10} style={{ marginBottom: 18 }}>
        {PARENT_KIDS.map((kid, i) => (
          <button key={i} onClick={() => setActive(i)} style={{
            display: "flex", alignItems: "center", gap: 10, padding: "8px 14px 8px 8px",
            borderRadius: 999, border: "none", cursor: "pointer",
            background: active === i ? "var(--surface)" : "transparent",
            boxShadow: active === i ? "var(--card-sh)" : "none",
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: "50%", background: kid.color,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
            }}>{kid.glyph}</div>
            <div style={{ textAlign: dir === "rtl" ? "right" : "left" }}>
              <div style={{ fontFamily: "var(--display-font)", fontWeight: 700, fontSize: 13 }}>{kid.name}</div>
              <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{kid.age} {lang === "ar" ? "سنوات" : "yrs"}</div>
            </div>
          </button>
        ))}
      </Stack>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 14 }}>
        {[
          { label: T("timeSpent"), val: `${k.today}m`, color: "var(--primary)", icon: "clock" },
          { label: T("streak"), val: k.streak, color: "var(--red)", icon: "flame" },
          { label: T("avgScore"), val: `${k.score}%`, color: "var(--green)", icon: "trophy" },
          { label: T("topSubject"), val: T(k.top), color: "var(--violet)", icon: "star" },
        ].map((s, i) => (
          <div key={i} className="card" style={{ padding: 14, display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 12, background: `color-mix(in oklab, ${s.color} 18%, white)`,
              color: s.color, display: "flex", alignItems: "center", justifyContent: "center", flex: "0 0 auto",
            }}><Icon name={s.icon} size={18} /></div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 20, fontWeight: 800, lineHeight: 1 }}>{s.val}</div>
              <div style={{ fontSize: 10, color: "var(--ink-soft)", fontWeight: 700, marginTop: 2 }}>{s.label}</div>
            </div>
          </div>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 14, marginBottom: 18 }}>
        <div className="card" style={{ padding: 18 }}>
          <Stack dir="row" justify="space-between" align="center" style={{ marginBottom: 14 }}>
            <h3 style={{ fontFamily: "var(--display-font)", margin: 0, fontSize: 15 }}>{T("weeklyProgress")}</h3>
            <Tag color="var(--primary)">+18%</Tag>
          </Stack>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height: 140 }}>
            {k.week.map((v, i) => {
              const days = lang === "ar" ? ["س","أ","ث","ر","خ","ج","س"] : ["S","M","T","W","T","F","S"];
              const max = Math.max(...k.week);
              return (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                  <div style={{
                    width: "100%", height: `${(v / max) * 110}px`,
                    background: i === 5 ? "var(--primary)" : `color-mix(in oklab, var(--primary) 35%, white)`,
                    borderRadius: 8,
                  }} />
                  <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{days[i]}</div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="card" style={{ padding: 18 }}>
          <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "حسب المادّة" : "By subject"}</h3>
          <Stack gap={10}>
            {[
              { sub: "math", v: 86, color: "var(--primary)" },
              { sub: "reading", v: 72, color: "var(--accent)" },
              { sub: "science", v: 60, color: "var(--green)" },
              { sub: "art", v: 48, color: "var(--red)" },
            ].map((r, i) => (
              <div key={i}>
                <Stack dir="row" justify="space-between" style={{ marginBottom: 4 }}>
                  <span style={{ fontWeight: 700, fontSize: 12 }}>{T(r.sub)}</span>
                  <span style={{ fontWeight: 800, fontSize: 12, color: "var(--ink-soft)" }} className="mono">{r.v}%</span>
                </Stack>
                <ProgressBar value={r.v} color={r.color} height={8} />
              </div>
            ))}
          </Stack>
        </div>
      </div>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>
          {lang === "ar" ? "آخر النشاطات" : "Recent activity"}
        </h3>
        <Stack gap={8}>
          {[
            { sub: "math",    title: lang === "ar" ? "العدّ من ١ إلى ١٠" : "Counting 1–10", score: 100, time: lang === "ar" ? "اليوم ٤:٢٠م" : "Today 4:20 PM", color: "var(--primary)" },
            { sub: "reading", title: lang === "ar" ? "حروف A–F" : "Letters A–F",            score: 80,  time: lang === "ar" ? "اليوم ٣:٤٥م" : "Today 3:45 PM", color: "var(--accent)" },
            { sub: "art",     title: lang === "ar" ? "تلوين الفواكه" : "Color the fruits",  score: 100, time: lang === "ar" ? "أمس" : "Yesterday",            color: "var(--red)" },
          ].map((a, i) => (
            <Stack key={i} dir="row" align="center" gap={12} style={{
              padding: "10px 12px", background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 12,
            }}>
              <div style={{
                width: 34, height: 34, borderRadius: 10, background: a.color, color: "#fff",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}><Icon name="check" size={18} color="#fff" /></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{a.title}</div>
                <div style={{ fontSize: 11, color: "var(--ink-soft)", fontWeight: 700 }}>{T(a.sub)} · {a.time}</div>
              </div>
              <Pill color={a.score === 100 ? "var(--green)" : "var(--yellow)"}>{a.score}%</Pill>
            </Stack>
          ))}
        </Stack>
      </div>
    </div>
  );
};

const ParentKids = ({ T, lang, dir }) => (
  <div>
    <PageHeader
      title={T("kids")}
      sub={lang === "ar" ? "إدارة ملفّات الأطفال" : "Manage your children's profiles"}
      actions={<button className="btn btn-primary" style={{ padding: "10px 16px", fontSize: 13 }}>
        <Icon name="plus" size={16} color="#fff" /> {lang === "ar" ? "إضافة طفل" : "Add child"}
      </button>}
    />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 }}>
      {PARENT_KIDS.map((k, i) => (
        <div key={i} className="card" style={{ padding: 18 }}>
          <Stack dir="row" gap={14} align="center">
            <div style={{
              width: 64, height: 64, borderRadius: "50%", background: k.color,
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 34,
              boxShadow: "0 4px 0 rgba(0,0,0,.08)",
            }}>{k.glyph}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "var(--display-font)", fontSize: 18 }}>{k.name}</div>
              <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700 }}>
                {k.age} {lang === "ar" ? "سنوات" : "years old"} · {lang === "ar" ? "المستوى" : "Level"} {Math.floor(k.score / 20)}
              </div>
            </div>
            <button className="btn btn-ghost" style={{ padding: "8px 14px", fontSize: 12 }}>
              {lang === "ar" ? "تعديل" : "Edit"}
            </button>
          </Stack>
          <div style={{ marginTop: 14 }}>
            <Stack dir="row" justify="space-between" style={{ marginBottom: 4 }}>
              <span style={{ fontWeight: 700, fontSize: 12 }}>{lang === "ar" ? "تقدّم الأسبوع" : "Week progress"}</span>
              <span className="mono" style={{ fontWeight: 800, fontSize: 12 }}>{k.score}%</span>
            </Stack>
            <ProgressBar value={k.score} color={k.color} height={8} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginTop: 14 }}>
            {[
              { l: T("streak"), v: k.streak, c: "var(--red)" },
              { l: T("topSubject"), v: T(k.top), c: "var(--violet)" },
              { l: T("timeSpent"), v: `${k.today}m`, c: "var(--primary)" },
            ].map((s, j) => (
              <div key={j} style={{
                background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 12, padding: 10, textAlign: "center",
              }}>
                <div style={{ fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 16, color: s.c }}>{s.v}</div>
                <div style={{ fontSize: 10, color: "var(--ink-soft)", fontWeight: 700, marginTop: 2 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
      <div className="card" style={{
        padding: 18, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column",
        gap: 10, border: "2px dashed color-mix(in oklab, var(--ink-soft) 30%, white)", boxShadow: "none",
        background: "transparent", color: "var(--ink-soft)", cursor: "pointer", minHeight: 200,
      }}>
        <div style={{
          width: 56, height: 56, borderRadius: "50%", background: "color-mix(in oklab, var(--primary) 15%, white)",
          color: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center",
        }}><Icon name="plus" size={28} /></div>
        <div style={{ fontFamily: "var(--display-font)", fontWeight: 700 }}>{lang === "ar" ? "أضف طفلًا جديدًا" : "Add a new child"}</div>
      </div>
    </div>
  </div>
);

const ParentProgress = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("weeklyProgress")} sub={lang === "ar" ? "تفاصيل الأداء" : "Detailed performance"} />
    <div className="card" style={{ padding: 20, marginBottom: 14 }}>
      <Stack dir="row" justify="space-between" align="center" style={{ marginBottom: 14 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: 0, fontSize: 16 }}>{lang === "ar" ? "النشاط اليومي" : "Daily activity"}</h3>
        <div className="seg" style={{
          display: "inline-flex", background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 999, padding: 3,
        }}>
          {(lang === "ar" ? ["يوم","أسبوع","شهر"] : ["Day","Week","Month"]).map((p, i) => (
            <button key={i} style={{
              background: i === 1 ? "var(--ink)" : "transparent", color: i === 1 ? "var(--bg)" : "var(--ink-soft)",
              border: "none", padding: "6px 14px", borderRadius: 999, fontWeight: 700, fontSize: 12, cursor: "pointer",
            }}>{p}</button>
          ))}
        </div>
      </Stack>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 14, height: 200, padding: "0 4px" }}>
        {PARENT_KIDS[0].week.map((v, i) => {
          const days = lang === "ar" ? ["س","أ","ث","ر","خ","ج","س"] : ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
          return (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
              <div style={{
                width: "100%", height: `${(v / 30) * 160}px`,
                background: `linear-gradient(180deg, var(--primary), var(--pink))`, borderRadius: 10,
              }} />
              <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700 }}>{days[i]}</div>
            </div>
          );
        })}
      </div>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 }}>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "نقاط القوّة" : "Strengths"}</h3>
        {[
          { sub: "math", v: 92, color: "var(--primary)" },
          { sub: "reading", v: 84, color: "var(--accent)" },
        ].map((r, i) => (
          <div key={i} style={{ marginBottom: 10 }}>
            <Stack dir="row" justify="space-between"><span style={{ fontWeight: 700, fontSize: 13 }}>{T(r.sub)}</span><span className="mono" style={{ fontWeight: 800, fontSize: 13 }}>{r.v}%</span></Stack>
            <ProgressBar value={r.v} color={r.color} height={8} />
          </div>
        ))}
      </div>
      <div className="card" style={{ padding: 18 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 12px", fontSize: 15 }}>{lang === "ar" ? "يحتاج تحسينًا" : "Needs improvement"}</h3>
        {[
          { sub: "science", v: 48, color: "var(--green)" },
          { sub: "art", v: 38, color: "var(--red)" },
        ].map((r, i) => (
          <div key={i} style={{ marginBottom: 10 }}>
            <Stack dir="row" justify="space-between"><span style={{ fontWeight: 700, fontSize: 13 }}>{T(r.sub)}</span><span className="mono" style={{ fontWeight: 800, fontSize: 13 }}>{r.v}%</span></Stack>
            <ProgressBar value={r.v} color={r.color} height={8} />
          </div>
        ))}
      </div>
    </div>
  </div>
);

const ParentRewards = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("rewards")} sub={lang === "ar" ? "الإنجازات والشارات" : "Achievements & badges"} />
    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14, marginBottom: 14 }}>
      {[
        { l: T("stars"), v: 124, c: "var(--yellow)", i: "star" },
        { l: T("coins"), v: 38, c: "var(--primary)", i: "coin" },
        { l: T("badges"), v: 4, c: "var(--violet)", i: "trophy" },
      ].map((s, i) => (
        <div key={i} className="card" style={{ padding: 20, textAlign: "center" }}>
          <div style={{
            width: 48, height: 48, margin: "0 auto 10px", borderRadius: 14, background: s.c,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}><Icon name={s.i} size={24} color="#fff" /></div>
          <div style={{ fontFamily: "var(--display-font)", fontSize: 28, fontWeight: 800 }}>{s.v}</div>
          <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700 }}>{s.l}</div>
        </div>
      ))}
    </div>
    <div className="card" style={{ padding: 20 }}>
      <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 14px", fontSize: 16 }}>{T("badges")}</h3>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 10 }}>
        {[
          { name: lang === "ar" ? "بطل الرياضيات" : "Math hero", color: "var(--primary)", icon: "trophy", earned: true },
          { name: lang === "ar" ? "قارئ نجم" : "Star reader", color: "var(--accent)", icon: "book", earned: true },
          { name: lang === "ar" ? "عبقريّ الألوان" : "Color genius", color: "var(--pink)", icon: "palette", earned: true },
          { name: lang === "ar" ? "صائم ٧ أيام" : "7-day streak", color: "var(--red)", icon: "flame", earned: true },
          { name: lang === "ar" ? "عالِم صغير" : "Lil' scientist", color: "var(--green)", icon: "flask", earned: false },
          { name: lang === "ar" ? "مُبرمج" : "Coder", color: "var(--violet)", icon: "code", earned: false },
        ].map((b, i) => (
          <div key={i} style={{ textAlign: "center", padding: 12, opacity: b.earned ? 1 : 0.4 }}>
            <div style={{
              width: 56, height: 56, margin: "0 auto 6px", borderRadius: "50%",
              background: b.earned ? b.color : "rgba(0,0,0,.1)", color: "#fff",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: b.earned ? `0 4px 0 color-mix(in oklab, ${b.color} 60%, black)` : "none",
            }}><Icon name={b.icon} size={26} color="#fff" /></div>
            <div style={{ fontSize: 11, fontWeight: 800, lineHeight: 1.2 }}>{b.name}</div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const ParentLimits = ({ T, lang, dir }) => {
  const [limit, setLimit] = React.useState(45);
  return (
    <div>
      <PageHeader title={T("setLimit")} sub={lang === "ar" ? "حماية وقت الشاشة" : "Healthy screen time"} />
      <div className="card" style={{ padding: 22, marginBottom: 14 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 14px", fontSize: 16 }}>{lang === "ar" ? "الحدّ اليومي" : "Daily time limit"}</h3>
        <Stack dir="row" align="center" gap={20}>
          <div style={{ fontFamily: "var(--display-font)", fontSize: 56, fontWeight: 800, color: "var(--primary)", minWidth: 120 }}>
            {limit}<span style={{ fontSize: 22, color: "var(--ink-soft)" }}>min</span>
          </div>
          <input type="range" min="15" max="120" step="15" value={limit} onChange={e => setLimit(+e.target.value)}
            style={{ flex: 1, accentColor: "var(--primary)" }} />
        </Stack>
        <Stack dir="row" gap={8} style={{ marginTop: 14, flexWrap: "wrap" }}>
          {[15, 30, 45, 60, 90, 120].map(v => (
            <button key={v} onClick={() => setLimit(v)} style={{
              padding: "8px 14px", borderRadius: 999, border: "none", cursor: "pointer",
              background: limit === v ? "var(--primary)" : "color-mix(in oklab, var(--bg) 60%, white)",
              color: limit === v ? "#fff" : "var(--ink)", fontWeight: 700, fontSize: 12,
            }}>{v}m</button>
          ))}
        </Stack>
      </div>
      <div className="card" style={{ padding: 22 }}>
        <h3 style={{ fontFamily: "var(--display-font)", margin: "0 0 14px", fontSize: 16 }}>{lang === "ar" ? "أوقات السماح" : "Allowed times"}</h3>
        <Stack gap={10}>
          {[
            { l: lang === "ar" ? "أيام الأسبوع" : "Weekdays", v: "3:00 PM – 7:00 PM", on: true },
            { l: lang === "ar" ? "نهاية الأسبوع" : "Weekends", v: "10:00 AM – 8:00 PM", on: true },
            { l: lang === "ar" ? "وقت النوم" : "Bedtime block", v: "9:00 PM – 7:00 AM", on: true },
          ].map((r, i) => (
            <Stack key={i} dir="row" justify="space-between" align="center" style={{
              padding: "12px 14px", background: "color-mix(in oklab, var(--bg) 60%, white)", borderRadius: 12,
            }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 14 }}>{r.l}</div>
                <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700 }}>{r.v}</div>
              </div>
              <div style={{
                width: 44, height: 26, borderRadius: 999, background: r.on ? "var(--green)" : "rgba(0,0,0,.15)",
                position: "relative",
              }}>
                <div style={{
                  position: "absolute", top: 3, left: r.on ? 21 : 3,
                  width: 20, height: 20, borderRadius: "50%", background: "#fff",
                }} />
              </div>
            </Stack>
          ))}
        </Stack>
      </div>
    </div>
  );
};

const ParentSettings = ({ T, lang, dir }) => (
  <div>
    <PageHeader title={T("settings")} sub={lang === "ar" ? "تفضيلات الحساب" : "Account preferences"} />
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 14 }}>
      <div className="card" style={{ padding: 22, textAlign: "center" }}>
        <div style={{
          width: 90, height: 90, margin: "0 auto 12px", borderRadius: "50%",
          background: "linear-gradient(135deg, var(--primary), var(--pink))",
          display: "flex", alignItems: "center", justifyContent: "center", color: "#fff",
          fontFamily: "var(--display-font)", fontWeight: 800, fontSize: 36,
        }}>S</div>
        <div style={{ fontFamily: "var(--display-font)", fontSize: 18 }}>Sara Hassan</div>
        <div style={{ fontSize: 12, color: "var(--ink-soft)", fontWeight: 700, marginBottom: 14 }}>sara@example.com</div>
        <button className="btn btn-ghost" style={{ padding: "8px 16px", fontSize: 12 }}>{lang === "ar" ? "تعديل الملف" : "Edit profile"}</button>
      </div>
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {[
          { i: "bell", l: lang === "ar" ? "الإشعارات" : "Notifications", v: lang === "ar" ? "مفعّلة" : "On" },
          { i: "lock", l: T("parentZone"), v: lang === "ar" ? "PIN مفعّل" : "PIN set" },
          { i: "palette", l: lang === "ar" ? "السمة" : "Theme", v: lang === "ar" ? "فاتح" : "Light" },
          { i: "speaker", l: lang === "ar" ? "اللغة" : "Language", v: lang === "ar" ? "العربية" : "English" },
          { i: "user", l: lang === "ar" ? "الفوترة" : "Billing", v: "Family Plan" },
          { i: "x", l: T("logOut"), v: "" },
        ].map((row, i, arr) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", gap: 14, padding: "14px 18px",
            borderBottom: i < arr.length - 1 ? "1px solid rgba(0,0,0,.05)" : "none",
            cursor: "pointer",
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10, background: "color-mix(in oklab, var(--primary) 15%, white)",
              color: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center",
            }}><Icon name={row.i} size={18} /></div>
            <div style={{ flex: 1, fontWeight: 700, fontSize: 14 }}>{row.l}</div>
            <div style={{ color: "var(--ink-soft)", fontWeight: 700, fontSize: 13 }}>{row.v}</div>
            <Icon name={dir === "rtl" ? "chevronL" : "chevron"} size={18} color="var(--ink-soft)" />
          </div>
        ))}
      </div>
    </div>
  </div>
);

const ParentDashboard = ({ T, lang, dir }) => {
  const [page, setPage] = React.useState("overview");
  return (
    <div style={{ display: "flex", height: "100%", background: "var(--bg)", color: "var(--ink)" }}>
      <ParentSidebar T={T} dir={dir} page={page} setPage={setPage} />
      <main style={{ flex: 1, padding: 22, overflow: "auto" }}>
        {page === "overview" && <ParentOverview T={T} lang={lang} dir={dir} />}
        {page === "kids"     && <ParentKids T={T} lang={lang} dir={dir} />}
        {page === "progress" && <ParentProgress T={T} lang={lang} dir={dir} />}
        {page === "rewards"  && <ParentRewards T={T} lang={lang} dir={dir} />}
        {page === "limits"   && <ParentLimits T={T} lang={lang} dir={dir} />}
        {page === "settings" && <ParentSettings T={T} lang={lang} dir={dir} />}
      </main>
    </div>
  );
};

window.ParentDashboard = ParentDashboard;
window.PageHeader = PageHeader;
